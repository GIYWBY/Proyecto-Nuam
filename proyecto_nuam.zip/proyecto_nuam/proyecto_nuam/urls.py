"""
URL configuration for proyecto_nuam project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from nuam import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('registrar_corredor/', views.registrar_corredor, name='registrar_corredor'),
    path('ingresar_corredor/', views.ingresar_corredor, name='ingresar_corredor'),
    path('home/', views.home, name='home'),
    path('salir/', views.salir, name='salir'),
    path('subir_documentos/', views.subir_documentos, name='subir_documentos'),
    path('descargar_subida/zip/<int:subida_id>/', views.descargar_subida, name='descargar_subida'),
    path('descargar_subidas/', views.descargar_subidas, name='descargar_subidas'),
    path('corredor_subidas/', views.corredor_subidas, name='corredor_subidas'),
    path('enviar_mensaje/', views.enviar_mensaje, name='enviar_mensaje'),
    path('buscar/', views.buscar, name='buscar'),
    path('eliminar_subida/<int:subida_id>/', views.eliminar_subida, name='eliminar_subida'),
]
