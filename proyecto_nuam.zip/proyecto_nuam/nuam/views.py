import os
from io import BytesIO
import zipfile
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect
import bcrypt
from .models import Corredor, Documento, Subida, Mensaje, Supervisor, Coordinador, Directivo, Log
from django.contrib.auth import logout as log_out
from datetime import datetime
from localflavor.cl.forms import CLRutField

def error(e):
    print(f"ERROR: {e}")

def hashear_contraseña(contraseña):
    sal_generada = bcrypt.gensalt()
    hash_resultante = bcrypt.hashpw(contraseña.encode('utf-8'), sal_generada)
    return hash_resultante

def verificar_contraseña(contraseña, hash_almacenado):
    contraseña_bytes = contraseña.encode('utf-8')
    return bcrypt.checkpw(contraseña_bytes, hash_almacenado)

def is_valid_extension(archivo):
    valid_extensions = ['.pdf', '.csv']
    if not archivo:
        return True 
    
    ext = os.path.splitext(archivo.name)[1]
    return ext.lower() in valid_extensions

clave_nuam_supervisor = hashear_contraseña("nuam_2025")
clave_nuam_coordinador = hashear_contraseña("nuam_2025")
clave_nuam_directivo = hashear_contraseña("nuam_2025")

# Create your views here.

def index(request):
    return render(request, 'index.html')

def login_administrador(request):
    return render(request, 'login_administrador.html')

def registrar_corredor(request):
    if request.method == "POST":
        nombre_usuario = request.POST.get("nombre_usuario")
        apellido_usuario = request.POST.get("apellido_usuario")
        rut = request.POST.get("rut")
        correo = request.POST.get("correo")
        correo_confirmar = request.POST.get("correo_confirmar")
        contraseña = request.POST.get("contraseña")
        contraseña_confirmar = request.POST.get("contraseña_confirmar")
    
        try:
            if correo == correo_confirmar and contraseña == contraseña_confirmar:
                validar_rut = CLRutField()
                rut_validado = validar_rut.clean(rut)
                contraseña_hasheada = hashear_contraseña(contraseña)

                corredor = Corredor.objects.create(
                    nombre_usuario=nombre_usuario,
                    apellido_usuario=apellido_usuario,
                    rut=rut_validado,
                    correo=correo,
                    contraseña=contraseña_hasheada
                )

                logs = Log.objects.create(
                    usuario=corredor,
                    accion='Se creó el usuario'
                )

                data = {
                    'corredor': corredor,
                    'mensaje': "Se ha registrado con éxito"
                }

                return render(request, 'index.html', data)
            else:
                data = {
                    'mensaje': "Ha ocurrido un error durante el registro"
                }

                return render(request, 'index.html', data)

        except Exception as e:
            error(e)

            data = {
                'mensaje': "Ha ocurrido un error durante el registro"
            }

            return render(request, 'index.html', data)
    
    else:
        return redirect("index")

def ingresar_corredor(request):
    if request.method == 'GET':
        rut = request.GET.get('rut')
        contraseña = request.GET.get('contraseña')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            corredor = Corredor.objects.get(rut=rut_validado)

            if verificar_contraseña(contraseña, corredor.contraseña):
                request.session['usuario_id'] = corredor.id
                request.session.modified = True

                logs = Log.objects.create(
                    usuario=corredor,
                    accion='Inició sesión'
                )

                return redirect('home')
            else:
                data = {
                    'mensaje': "Los datos ingresados no coinciden con ninguna cuenta registrada"
                }
                return render(request, 'index.html', data)    

        except Exception as e:
            error(e)
            data = {
                'mensaje': "Ha ocurrido un error durante el ingreso"
            }
            return render(request, 'index.html', data)
        
    else:
        return redirect('index')

def home(request):
    if 'usuario_id' in request.session:
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            subidas_corredor = Subida.objects.filter(corredor=corredor).order_by('-id').prefetch_related('documento_set')
            mensajes = Mensaje.objects.filter(destinatario=corredor)
            usuarios = Corredor.objects.filter().order_by('-id')

            data = {
                'corredor': corredor,
                'subidas': subidas,
                'subidas_corredor': subidas_corredor,
                'mensajes': mensajes,
                'usuarios': usuarios
            }

            return render(request, 'home.html', data)
        except Exception as e:
            error(e)
            return redirect('index')
    else:
        return redirect('index')

def home_administrador(request):
    if 'supervisor_id' in request.session:
        try:
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            mensajes = Mensaje.objects.filter(destinatario=supervisor)
            usuarios = Corredor.objects.filter().order_by('-id')
            logs = Log.objects.filter().order_by('-id')

            data = {
                'supervisor': supervisor,
                'subidas': subidas,
                'mensajes': mensajes,
                'usuarios': usuarios,
                'logs':logs
            }

            return render(request, 'home_supervisor.html', data)
        except Exception as e:
            error(e)
            return redirect('login_administrador')
    
    elif 'coordinador_id' in request.session:
        try:
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            usuarios = Supervisor.objects.filter().order_by('-id')
            logs = Log.objects.filter().order_by('-id')

            data = {
                'coordinador': coordinador,
                'subidas': subidas,
                'usuarios': usuarios,
                'logs':logs
            }

            return render(request, 'home_coordinador.html', data)
        except Exception as e:
            error(e)
            return redirect('login_administrador')

    elif 'directivo_id' in request.session:
        try:
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            usuarios = Corredor.objects.filter().order_by('-id')

            data = {
                'directivo': directivo,
                'subidas': subidas,
                'usuarios': usuarios
            }

            return render(request, 'home_directivo.html', data)
        except Exception as e:
            error(e)
            return redirect('login_administrador')
    else:
        return redirect('login_administrador')

def salir(request):
    if 'usuario_id' in request.session:
        corredor = Corredor.objects.get(id=request.session['usuario_id'])
        
        log_out(request)

        logs = Log.objects.create(
            usuario=corredor,
            accion='Salió de la sesión'
        )

        return redirect('index')
    else:
        return redirect('index')
    
def subir_documentos(request):
    if 'usuario_id' in request.session:
        titulo = request.POST.get("titulo")
        descripcion = request.POST.get("descripcion")
        tipo_subida = request.POST.get("tipo_subida")
        archivo = request.FILES.getlist("archivo[]")
        
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            if archivo:
                for file in archivo:
                    if file and not is_valid_extension(file):
                        print("El archivo no es valido")
                        return redirect('home')
                subida = Subida.objects.create(titulo=titulo, descripcion=descripcion, tipo_subida=tipo_subida, corredor=corredor)

                logs = Log.objects.create(
                    usuario=corredor,
                    accion='Hizo una subida'
                )

                for file in archivo:
                    if file and not is_valid_extension(file):
                        print("El archivo no es valido")
                        return redirect('home')
                    else:
                        documento = Documento.objects.create(archivo=file, subida=subida)
                        documento.save()
                return redirect('home')
            else:                
                return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def descargar_subida(request, subida_id):
    if 'usuario_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            buffer = BytesIO()
            with zipfile.ZipFile(buffer, 'w') as zip_file:
                for doc in documentos:
                    ruta_relativa = doc.archivo.name
                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                    if os.path.exists(ruta_archivo):
                        zip_file.write(
                            ruta_archivo, 
                            arcname=doc.archivo.name
                        )
            buffer.seek(0)

            response = HttpResponse(buffer.read())
            response['Content-Type'] = 'application/zip'
            response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

            logs = Log.objects.create(
                usuario=corredor,
                accion=f'Descargó una subida ({subida.id})'
            )

            return response
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def descargar_subida_supervisor(request, subida_id):
    if 'supervisor_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            buffer = BytesIO()
            with zipfile.ZipFile(buffer, 'w') as zip_file:
                for doc in documentos:
                    ruta_relativa = doc.archivo.name
                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                    if os.path.exists(ruta_archivo):
                        zip_file.write(
                            ruta_archivo, 
                            arcname=doc.archivo.name
                        )
            buffer.seek(0)

            response = HttpResponse(buffer.read())
            response['Content-Type'] = 'application/zip'
            response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

            logs = Log.objects.create(
                usuario=supervisor,
                accion=f'Descargó una subida ({subida.id})'
            )

            return response
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subida_coordinador(request, subida_id):
    if 'coordinador_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            buffer = BytesIO()
            with zipfile.ZipFile(buffer, 'w') as zip_file:
                for doc in documentos:
                    ruta_relativa = doc.archivo.name
                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                    if os.path.exists(ruta_archivo):
                        zip_file.write(
                            ruta_archivo, 
                            arcname=doc.archivo.name
                        )
            buffer.seek(0)

            response = HttpResponse(buffer.read())
            response['Content-Type'] = 'application/zip'
            response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

            logs = Log.objects.create(
                usuario=coordinador,
                accion=f'Descargó una subida ({subida.id})'
            )

            return response
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subida_directivo(request, subida_id):
    if 'directivo_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            directivo = Directivo.objects.get(id=request.session['directivo_id'])

            buffer = BytesIO()
            with zipfile.ZipFile(buffer, 'w') as zip_file:
                for doc in documentos:
                    ruta_relativa = doc.archivo.name
                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                    if os.path.exists(ruta_archivo):
                        zip_file.write(
                            ruta_archivo, 
                            arcname=doc.archivo.name
                        )
            buffer.seek(0)

            response = HttpResponse(buffer.read())
            response['Content-Type'] = 'application/zip'
            response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

            logs = Log.objects.create(
                usuario=directivo,
                accion=f'Descargó una subida ({subida.id})'
            )

            return response
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subidas(request):
    if 'usuario_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                corredor = Corredor.objects.get(id=request.session['corredor_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                        usuario=corredor,
                        accion=f'Descargó subidas {sub.id}'
                    )

                return response
            except Exception as e:
                print(f"ERROR: {e}") 
                return redirect('home')
        else:
            return redirect('home')
    else:
        return redirect('index')

def descargar_subidas_supervisor(request):
    if 'supervisor_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                    usuario=supervisor,
                    accion=f'Descargó subidas {sub.id}'
                )

                return response
            except Exception as e:
                print(f"ERROR: {e}")
                return redirect('home_administrador')
        else:
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def descargar_subidas_coordinador(request):
    if 'coordinador_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                    usuario=coordinador,
                    accion=f'Descargó subidas {sub.id}'
                )

                return response
            except Exception as e:
                print(f"ERROR: {e}")
                return redirect('home_administrador')
        else:
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subidas_directivo(request):
    if 'directivo_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                directivo = Directivo.objects.get(id=request.session['directivo_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                    usuario=directivo,
                    accion=f'Descargó subidas {sub.id}'
                )

                return response
            except Exception as e:
                print(f"ERROR: {e}")
                return redirect('home_administrador')
        else:
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def corredor_subidas(request):
    if 'usuario_id' in request.session:
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            subidas = Subida.objects.filter(corredor=corredor).order_by('-id')
            mensajes = Mensaje.objects.filter(destinatario=corredor)

            data = {
                'corredor':corredor,
                'subidas':subidas,
                'mensajes':mensajes
            }

            return render(request, 'corredor_subidas.html', data)
        except Exception as e:
            error(e)
            return redirect('index')
    else:
        return redirect('index')

def enviar_mensaje(request):
    if 'usuario_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            destinatario = Corredor.objects.get(rut=rut_validado)

            mensaje = Mensaje.objects.create(
                titulo=titulo,
                contenido=descripcion,
                emisor=corredor,
                destinatario=destinatario
            )

            return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def enviar_mensaje_supervisor(request):
    if 'supervisor_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            
            try:
                destinatario = Corredor.objects.get(rut=rut_validado)
                mensaje = Mensaje.objects.create(
                    titulo=titulo,
                    contenido=descripcion,
                    emisor=supervisor,
                    destinatario=destinatario
                )

                return redirect('home_administrador')
            except:
                try:
                    destinatario = Supervisor.objects.get(rut=rut_validado)
                    mensaje = Mensaje.objects.create(
                        titulo=titulo,
                        contenido=descripcion,
                        emisor=supervisor,
                        destinatario=destinatario
                    )

                    return redirect('home_administrador')
                except Exception as e:
                    error(e)
                    return redirect('home_administrador')     
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def enviar_mensaje_coordinador(request):
    if 'coordinador_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            try:
                destinatario = Directivo.objects.get(rut=rut_validado)
                mensaje = Mensaje.objects.create(
                    titulo=titulo,
                    contenido=descripcion,
                    emisor=coordinador,
                    destinatario=destinatario
                )

                return redirect('home_administrador')
            except:
                try:
                    destinatario = Coordinador.objects.get(rut=rut_validado)
                    mensaje = Mensaje.objects.create(
                        titulo=titulo,
                        contenido=descripcion,
                        emisor=coordinador,
                        destinatario=destinatario
                    )

                    return redirect('home_administrador')
                except:
                    try:
                        destinatario = Supervisor.objects.get(rut=rut_validado)
                        mensaje = Mensaje.objects.create(
                            titulo=titulo,
                            contenido=descripcion,
                            emisor=coordinador,
                            destinatario=destinatario
                        )

                        return redirect('home_administrador')
                    except Exception as e:
                        error(e)
                        return redirect('home_administrador')     
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def enviar_mensaje_directivo(request):
    if 'directivo_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            
            try:
                destinatario = Directivo.objects.get(rut=rut_validado)
                mensaje = Mensaje.objects.create(
                    titulo=titulo,
                    contenido=descripcion,
                    emisor=directivo,
                    destinatario=destinatario
                )

                return redirect('home_administrador')
            except:
                try:
                    destinatario = Coordinador.objects.get(rut=rut_validado)
                    mensaje = Mensaje.objects.create(
                        titulo=titulo,
                        contenido=descripcion,
                        emisor=directivo,
                        destinatario=destinatario
                    )

                    return redirect('home_administrador')
                except Exception as e:
                    error(e)
                    return redirect('home_administrador')     
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def buscar(request):
    if 'usuario_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            mensajes = Mensaje.objects.filter(destinatario=corredor)
            corredores = Corredor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

            data = {
                'usuarios': corredores,
                'corredor': corredor,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home.html', data)

        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')
    
def buscar_supervisor(request):
    if 'supervisor_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            mensajes = Mensaje.objects.filter(destinatario=supervisor)
            corredores = Corredor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

            data = {
                'usuarios': corredores,
                'supervisor': supervisor,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home_supervisor.html', data)

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def buscar_coordinador(request):
    if 'coordinador_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            mensajes = Mensaje.objects.filter(destinatario=coordinador)
            supervisores = Supervisor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

            data = {
                'usuarios': supervisores,
                'coordinador': coordinador,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home_supervisor.html', data)

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def buscar_directivo(request):
    if 'directivo_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            mensajes = Mensaje.objects.filter(destinatario=directivo)

            data = {
                'directivo': directivo,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home_supervisor.html', data)

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def eliminar_subida(request, subida_id):
    if 'usuario_id' in request.session:
        corredor = Corredor.objects.get(id=request.session['usuario_id'])
        subida = Subida.objects.get(id=subida_id, corredor=corredor)
        documentos = Documento.objects.filter(subida=subida)

        try:
            for doc in documentos:
                doc.archivo.delete(save=False)

            logs = Log.objects.create(
                usuario=corredor,
                accion=f'Elimino una subida ({subida.id})'
            )

            subida.delete()

            return redirect('home')

        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')
    
def eliminar_subida_supervisor(request, subida_id):
    if 'supervisor_id' in request.session:
        supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            for doc in documentos:
                doc.archivo.delete(save=False)

            logs = Log.objects.create(
                usuario=supervisor,
                accion=f'Elimino una subida ({subida.id})'
            )

            subida.delete()

            return redirect('home_administrador')

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('index')

def registrar_administrador(request):
    if request.method == "POST":
        nombre_usuario = request.POST.get("nombre_usuario")
        apellido_usuario = request.POST.get("apellido_usuario")
        rut = request.POST.get("rut")
        correo = request.POST.get("correo")
        correo_confirmar = request.POST.get("correo_confirmar")
        contraseña = request.POST.get("contraseña")
        contraseña_confirmar = request.POST.get("contraseña_confirmar")
        tipo_administrador = request.POST.get("tipo_administrador")
        clave_nuam_ingresada = request.POST.get('clave_nuam')

        try:
            if correo == correo_confirmar and contraseña == contraseña_confirmar:
                if tipo_administrador == "supervisor" and verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    validar_rut = CLRutField()
                    rut_validado = validar_rut.clean(rut)
                    contraseña_hasheada = hashear_contraseña(contraseña)

                    supervisor = Supervisor.objects.create(
                        nombre_usuario=nombre_usuario,
                        apellido_usuario=apellido_usuario,
                        rut=rut_validado,
                        correo=correo,
                        contraseña=contraseña_hasheada
                    )

                    logs = Log.objects.create(
                        usuario=supervisor,
                        accion='Se creó el usuario'
                    )

                    data = {
                        'corredor': supervisor,
                        'mensaje': "Se ha registrado con éxito"
                    }

                    return render(request, 'login_administrador.html', data)
                elif tipo_administrador == "coordinador" and verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    validar_rut = CLRutField()
                    rut_validado = validar_rut.clean(rut)
                    contraseña_hasheada = hashear_contraseña(contraseña)

                    coordinador = Coordinador.objects.create(
                        nombre_usuario=nombre_usuario,
                        apellido_usuario=apellido_usuario,
                        rut=rut_validado,
                        correo=correo,
                        contraseña=contraseña_hasheada
                    )

                    logs = Log.objects.create(
                        usuario=coordinador,
                        accion='Se creó el usuario'
                    )

                    data = {
                        'corredor': coordinador,
                        'mensaje': "Se ha registrado con éxito"
                    }

                    return render(request, 'login_administrador.html', data)
                elif tipo_administrador == "directivo" and verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    validar_rut = CLRutField()
                    rut_validado = validar_rut.clean(rut)
                    contraseña_hasheada = hashear_contraseña(contraseña)

                    directivo = Directivo.objects.create(
                        nombre_usuario=nombre_usuario,
                        apellido_usuario=apellido_usuario,
                        rut=rut_validado,
                        correo=correo,
                        contraseña=contraseña_hasheada
                    )

                    logs = Log.objects.create(
                        usuario=directivo,
                        accion='Se creó el usuario'
                    )

                    data = {
                        'corredor': directivo,
                        'mensaje': "Se ha registrado con éxito"
                    }

                    return render(request, 'login_administrador.html', data)
                else:
                    data = {
                        'mensaje': "La clave nuam es incorrecta"
                    }

                    return render(request, 'login_administrador.html', data)
            else:
                data = {
                    'mensaje': "Ha ocurrido un error durante el registro"
                }

                return render(request, 'login_administrador.html', data)
        except Exception as e:
            error(e)

            data = {
                'mensaje': "Ha ocurrido un error durante el registro"
            }

            return render(request, 'login_administrador.html', data)
    else:
        return redirect("login_administrador")

def ingresar_administrador(request):
    if request.method == "GET":
        rut = request.GET.get('rut')
        contraseña = request.GET.get('contraseña')
        clave_nuam_ingresada = request.GET.get('clave_nuam')

        try:
            validar_rut = CLRutField()
            rut = validar_rut.clean(rut)
            supervisor = Supervisor.objects.get(rut=rut)
            if verificar_contraseña(contraseña, supervisor.contraseña):
                if verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    request.session['supervisor_id'] = supervisor.id
                    request.session.modified = True

                    logs = Log.objects.create(
                        usuario=supervisor,
                        accion='Inició sesión'
                    )

                    return redirect('home_administrador')
                else:
                    data = {
                        'mensaje': "Los datos no son correctos"
                    }
                    return render(request, 'login_administrador.html', data)
            else:
                data = {
                        'mensaje': "Los datos no son correctos"
                }
                return render(request, 'login_administrador.html', data)
        except:
            try:
                validar_rut = CLRutField()
                rut = validar_rut.clean(rut)
                coordinador = Coordinador.objects.get(rut=rut)
                if verificar_contraseña(contraseña, coordinador.contraseña):
                    if verificar_contraseña(clave_nuam_ingresada, clave_nuam_coordinador):
                        request.session['coordinador_id'] = coordinador.id
                        request.session.modified = True

                        logs = Log.objects.create(
                            usuario=coordinador,
                            accion='Inició sesión'
                        )

                        return redirect('home_administrador')
                    else:
                        data = {
                            'mensaje': "Los datos no son correctos"
                        }
                        return render(request, 'login_administrador.html', data)
                else:
                    data = {
                        'mensaje': "Los datos no son correctos"
                    }
                    return render(request, 'login_administrador.html', data)
            except:
                try:
                    validar_rut = CLRutField()
                    rut = validar_rut.clean(rut)
                    directivo = Directivo.objects.get(rut=rut)
                    if verificar_contraseña(contraseña, directivo.contraseña):
                        if verificar_contraseña(clave_nuam_ingresada, clave_nuam_directivo):
                            request.session['directivo_id'] = directivo.id
                            request.session.modified = True

                            logs = Log.objects.create(
                                usuario=directivo,
                                accion='Inició sesión'
                            )

                            return redirect('home_administrador')
                        else:
                            data = {
                                'mensaje': "Los datos no son correctos"
                            }
                            return render(request, 'login_administrador.html', data)
                    else:
                        data = {
                            'mensaje': "Los datos no son correctos"
                        }
                        return render(request, 'login_administrador.html', data)
                except:
                    data = {
                        'mensaje': "Los datos ingresados no coinciden con ninguna cuenta registrada"
                    }
                    return render(request, 'login_administrador.html', data)
    else:
        return redirect('login_administrador')
    
def salir_administrador(request):
    if 'supervisor_id' in request.session:

        supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])

        logs = Log.objects.create(
            usuario=supervisor,
            accion='Salió de la sesión'
        )

        log_out(request)
        return redirect('login_administrador')
    elif 'coordinador_id' in request.session:

        coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])

        logs = Log.objects.create(
            usuario=coordinador,
            accion='Salió de la sesión'
        )

        log_out(request)
        return redirect('login_administrador')
    elif 'directivo_id' in request.session:
        
        directivo = Directivo.objects.get(id=request.session['directivo_id'])

        logs = Log.objects.create(
            usuario=directivo,
            accion='Salió de la sesión'
        )

        log_out(request)
        return redirect('login_administrador')
    else:
        return redirect('login_administrador')

def aprobar(request, subida_id):
    if 'supervisor_id' in request.session:
        supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
        subida = Subida.objects.get(id=subida_id)

        try:
            logs = Log.objects.create(
                usuario=supervisor,
                accion=f'Aprovó una subida ({subida.id})'
            )

            subida.estado = 'Aceptado'
            subida.save()

            return redirect('home_administrador')

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('index')