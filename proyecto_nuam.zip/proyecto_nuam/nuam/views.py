import os
from io import BytesIO
import zipfile
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect
import bcrypt
from .models import Corredor, Documento, Subida, Mensaje, Supervisor, Coordinador, Directivo, Log
from django.contrib.auth import logout as log_out
from datetime import datetime
from localflavor.cl.forms import CLRutField
from fpdf import FPDF
from django.core.files.base import ContentFile
from decimal import Decimal

def error(e):
    print(f"ERROR: {e}")

def hashear_contraseña(contraseña):
    sal_generada = bcrypt.gensalt()
    hash_resultante = bcrypt.hashpw(contraseña.encode('utf-8'), sal_generada)
    return hash_resultante

def verificar_contraseña(contraseña, hash_almacenado):
    contraseña_bytes = contraseña.encode('utf-8')
    return bcrypt.checkpw(contraseña_bytes, hash_almacenado)

def is_valid_extension(archivo):
    valid_extensions = ['.pdf', '.csv']
    if not archivo:
        return True 
    
    ext = os.path.splitext(archivo.name)[1]
    return ext.lower() in valid_extensions

clave_nuam_supervisor = hashear_contraseña("nuam_2025")
clave_nuam_coordinador = hashear_contraseña("nuam_2025")
clave_nuam_directivo = hashear_contraseña("nuam_2025")

# Create your views here.

def index(request):
    return render(request, 'index.html')

def login_administrador(request):
    return render(request, 'login_administrador.html')

def registrar_corredor(request):
    if request.method == "POST":
        nombre_usuario = request.POST.get("nombre_usuario")
        apellido_usuario = request.POST.get("apellido_usuario")
        rut = request.POST.get("rut")
        correo = request.POST.get("correo")
        correo_confirmar = request.POST.get("correo_confirmar")
        contraseña = request.POST.get("contraseña")
        contraseña_confirmar = request.POST.get("contraseña_confirmar")
    
        try:
            if correo == correo_confirmar and contraseña == contraseña_confirmar:
                validar_rut = CLRutField()
                rut_validado = validar_rut.clean(rut)
                contraseña_hasheada = hashear_contraseña(contraseña)

                corredor = Corredor.objects.create(
                    nombre_usuario=nombre_usuario,
                    apellido_usuario=apellido_usuario,
                    rut=rut_validado,
                    correo=correo,
                    contraseña=contraseña_hasheada
                )

                logs = Log.objects.create(
                    usuario=corredor,
                    accion='Se creó el usuario'
                )

                data = {
                    'corredor': corredor,
                    'mensaje': "Se ha registrado con éxito"
                }

                return render(request, 'index.html', data)
            else:
                data = {
                    'mensaje': "Ha ocurrido un error durante el registro"
                }

                return render(request, 'index.html', data)

        except Exception as e:
            error(e)

            data = {
                'mensaje': "Ha ocurrido un error durante el registro"
            }

            return render(request, 'index.html', data)
    
    else:
        return redirect("index")

def ingresar_corredor(request):
    if request.method == 'GET':
        rut = request.GET.get('rut')
        contraseña = request.GET.get('contraseña')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            corredor = Corredor.objects.get(rut=rut_validado)

            if verificar_contraseña(contraseña, corredor.contraseña):
                request.session['usuario_id'] = corredor.id
                request.session.modified = True

                logs = Log.objects.create(
                    usuario=corredor,
                    accion='Inició sesión'
                )

                return redirect('home')
            else:
                data = {
                    'mensaje': "Los datos ingresados no coinciden con ninguna cuenta registrada"
                }
                return render(request, 'index.html', data)    

        except Exception as e:
            error(e)
            data = {
                'mensaje': "Ha ocurrido un error durante el ingreso"
            }
            return render(request, 'index.html', data)
        
    else:
        return redirect('index')

def home(request):
    if 'usuario_id' in request.session:
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            subidas_corredor = Subida.objects.filter(corredor=corredor).order_by('-id').prefetch_related('documento_set')
            mensajes = Mensaje.objects.filter(destinatario=corredor)
            usuarios = Corredor.objects.filter().order_by('-id')

            data = {
                'corredor': corredor,
                'subidas': subidas,
                'subidas_corredor': subidas_corredor,
                'mensajes': mensajes,
                'usuarios': usuarios
            }

            return render(request, 'home.html', data)
        except Exception as e:
            error(e)
            return redirect('index')
    else:
        return redirect('index')

def home_administrador(request):
    if 'supervisor_id' in request.session:
        try:
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            mensajes = Mensaje.objects.filter(destinatario=supervisor)
            usuarios = Corredor.objects.filter().order_by('-id')
            logs = Log.objects.filter().order_by('-id')

            data = {
                'supervisor': supervisor,
                'subidas': subidas,
                'mensajes': mensajes,
                'usuarios': usuarios,
                'logs':logs
            }

            return render(request, 'home_supervisor.html', data)
        except Exception as e:
            error(e)
            return redirect('login_administrador')
    
    elif 'coordinador_id' in request.session:
        try:
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            usuarios = Supervisor.objects.filter().order_by('-id')
            logs = Log.objects.filter().order_by('-id')

            data = {
                'coordinador': coordinador,
                'subidas': subidas,
                'usuarios': usuarios,
                'logs':logs
            }

            return render(request, 'home_coordinador.html', data)
        except Exception as e:
            error(e)
            return redirect('login_administrador')

    elif 'directivo_id' in request.session:
        try:
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            usuarios = Corredor.objects.filter().order_by('-id')

            data = {
                'directivo': directivo,
                'subidas': subidas,
                'usuarios': usuarios
            }

            return render(request, 'home_directivo.html', data)
        except Exception as e:
            error(e)
            return redirect('login_administrador')
    else:
        return redirect('login_administrador')

def salir(request):
    if 'usuario_id' in request.session:
        corredor = Corredor.objects.get(id=request.session['usuario_id'])
        
        log_out(request)

        logs = Log.objects.create(
            usuario=corredor,
            accion='Salió de la sesión'
        )

        return redirect('index')
    else:
        return redirect('index')
    
def subir_documentos(request):
    if 'usuario_id' in request.session:
        titulo = request.POST.get("titulo")
        descripcion = request.POST.get("descripcion")
        tipo_subida = request.POST.get("tipo_subida")
        archivo = request.FILES.getlist("archivo[]")
        
        campos = [titulo, tipo_subida, archivo]

        try:
            if not any(campo == '' for campo in campos):
                corredor = Corredor.objects.get(id=request.session['usuario_id'])
                if archivo:
                    for file in archivo:
                        if file and not is_valid_extension(file):
                            print("El archivo no es valido")
                            return redirect('home')
                    subida = Subida.objects.create(titulo=titulo, descripcion=descripcion, tipo_subida=tipo_subida, corredor=corredor)

                    logs = Log.objects.create(
                        usuario=corredor,
                        accion='Hizo una subida'
                    )

                    for file in archivo:
                        if file and not is_valid_extension(file):
                            print("El archivo no es valido")
                            return redirect('home')
                        else:
                            documento = Documento.objects.create(archivo=file, subida=subida)
                            documento.save()
                    return redirect('home')
                else:                
                    return redirect('home')
            else:
                return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def descargar_subida(request, subida_id):
    if 'usuario_id' in request.session:
        try:
            subida = Subida.objects.get(id=subida_id)
            documentos = Documento.objects.filter(subida=subida)
        except Exception as e:
            error(e)
            return redirect('home')

        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])

            if documentos.count() == 1:
                doc = documentos.first()
                ruta_relativa = doc.archivo.name
                ruta_archivo_completa = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                if os.path.exists(ruta_archivo_completa):
                    with open(ruta_archivo_completa, 'rb') as f:
                        file_data = f.read()
                    
                    response = HttpResponse(file_data, content_type='application/octet-stream') 
                    response['Content-Disposition'] = f'attachment; filename="{os.path.basename(ruta_relativa)}"'

                    logs = Log.objects.create(
                        usuario=corredor,
                        accion=f'Descargó el documento {ruta_relativa} (Subida ID: {subida.id})'
                    )
                    return response
                else:
                    return redirect('home')
            
            else:
                buffer = BytesIO()
                with zipfile.ZipFile(buffer, 'w') as zip_file:
                    for doc in documentos:
                        ruta_relativa = doc.archivo.name
                        ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                        if os.path.exists(ruta_archivo):
                            zip_file.write(
                                ruta_archivo, 
                                arcname=doc.archivo.name
                            )
                buffer.seek(0)

                response = HttpResponse(buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

                logs = Log.objects.create(
                    usuario=corredor,
                    accion=f'Descargó una subida ({subida.id})'
                )

            return response
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def descargar_subida_supervisor(request, subida_id):
    if 'supervisor_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            if documentos.count() == 1:
                doc = documentos.first()
                ruta_relativa = doc.archivo.name
                ruta_archivo_completa = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                if os.path.exists(ruta_archivo_completa):
                    with open(ruta_archivo_completa, 'rb') as f:
                        file_data = f.read()
                    
                    response = HttpResponse(file_data, content_type='application/octet-stream') 
                    response['Content-Disposition'] = f'attachment; filename="{os.path.basename(ruta_relativa)}"'

                    logs = Log.objects.create(
                        usuario=supervisor,
                        accion=f'Descargó el documento {ruta_relativa} (Subida ID: {subida.id})'
                    )
                    return response
                else:
                    return redirect('home')
            
            else:
                buffer = BytesIO()
                with zipfile.ZipFile(buffer, 'w') as zip_file:
                    for doc in documentos:
                        ruta_relativa = doc.archivo.name
                        ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                        if os.path.exists(ruta_archivo):
                            zip_file.write(
                                ruta_archivo, 
                                arcname=doc.archivo.name
                            )
                buffer.seek(0)

                response = HttpResponse(buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

                logs = Log.objects.create(
                    usuario=supervisor,
                    accion=f'Descargó una subida ({subida.id})'
                )

            return response
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subida_coordinador(request, subida_id):
    if 'coordinador_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            if documentos.count() == 1:
                doc = documentos.first()
                ruta_relativa = doc.archivo.name
                ruta_archivo_completa = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                if os.path.exists(ruta_archivo_completa):
                    with open(ruta_archivo_completa, 'rb') as f:
                        file_data = f.read()
                    
                    response = HttpResponse(file_data, content_type='application/octet-stream') 
                    response['Content-Disposition'] = f'attachment; filename="{os.path.basename(ruta_relativa)}"'

                    logs = Log.objects.create(
                        usuario=coordinador,
                        accion=f'Descargó el documento {ruta_relativa} (Subida ID: {subida.id})'
                    )
                    return response
                else:
                    return redirect('home')
            
            else:
                buffer = BytesIO()
                with zipfile.ZipFile(buffer, 'w') as zip_file:
                    for doc in documentos:
                        ruta_relativa = doc.archivo.name
                        ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                        if os.path.exists(ruta_archivo):
                            zip_file.write(
                                ruta_archivo, 
                                arcname=doc.archivo.name
                            )
                buffer.seek(0)

                response = HttpResponse(buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

                logs = Log.objects.create(
                    usuario=coordinador,
                    accion=f'Descargó una subida ({subida.id})'
                )

            return response
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subida_directivo(request, subida_id):
    if 'directivo_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            if documentos.count() == 1:
                doc = documentos.first()
                ruta_relativa = doc.archivo.name
                ruta_archivo_completa = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                if os.path.exists(ruta_archivo_completa):
                    with open(ruta_archivo_completa, 'rb') as f:
                        file_data = f.read()
                    
                    response = HttpResponse(file_data, content_type='application/octet-stream') 
                    response['Content-Disposition'] = f'attachment; filename="{os.path.basename(ruta_relativa)}"'

                    logs = Log.objects.create(
                        usuario=directivo,
                        accion=f'Descargó el documento {ruta_relativa} (Subida ID: {subida.id})'
                    )
                    return response
                else:
                    return redirect('home')
            
            else:
                buffer = BytesIO()
                with zipfile.ZipFile(buffer, 'w') as zip_file:
                    for doc in documentos:
                        ruta_relativa = doc.archivo.name
                        ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                        if os.path.exists(ruta_archivo):
                            zip_file.write(
                                ruta_archivo, 
                                arcname=doc.archivo.name
                            )
                buffer.seek(0)

                response = HttpResponse(buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

                logs = Log.objects.create(
                    usuario=directivo,
                    accion=f'Descargó una subida ({subida.id})'
                )

            return response
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subidas(request):
    if 'usuario_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                corredor = Corredor.objects.get(id=request.session['usuario_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                        usuario=corredor,
                        accion=f'Descargó subidas {sub.id}'
                    )

                return response
            except Exception as e:
                print(f"ERROR: {e}") 
                return redirect('home')
        else:
            return redirect('home')
    else:
        return redirect('index')

def descargar_subidas_supervisor(request):
    if 'supervisor_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                    usuario=supervisor,
                    accion=f'Descargó subidas {sub.id}'
                )

                return response
            except Exception as e:
                print(f"ERROR: {e}")
                return redirect('home_administrador')
        else:
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def descargar_subidas_coordinador(request):
    if 'coordinador_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                    usuario=coordinador,
                    accion=f'Descargó subidas {sub.id}'
                )

                return response
            except Exception as e:
                print(f"ERROR: {e}")
                return redirect('home_administrador')
        else:
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def descargar_subidas_directivo(request):
    if 'directivo_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                subidas = []
                directivo = Directivo.objects.get(id=request.session['directivo_id'])
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            subidas.append(subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                for sub in subidas:
                    logs = Log.objects.create(
                    usuario=directivo,
                    accion=f'Descargó subidas {sub.id}'
                )

                return response
            except Exception as e:
                print(f"ERROR: {e}")
                return redirect('home_administrador')
        else:
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def corredor_subidas(request):
    if 'usuario_id' in request.session:
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            subidas = Subida.objects.filter(corredor=corredor).order_by('-id')
            mensajes = Mensaje.objects.filter(destinatario=corredor)

            data = {
                'corredor':corredor,
                'subidas':subidas,
                'mensajes':mensajes
            }

            return render(request, 'corredor_subidas.html', data)
        except Exception as e:
            error(e)
            return redirect('index')
    else:
        return redirect('index')

def enviar_mensaje(request):
    if 'usuario_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            destinatario = Corredor.objects.get(rut=rut_validado)

            mensaje = Mensaje.objects.create(
                titulo=titulo,
                contenido=descripcion,
                emisor=corredor,
                destinatario=destinatario
            )

            return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def enviar_mensaje_supervisor(request):
    if 'supervisor_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            
            try:
                destinatario = Corredor.objects.get(rut=rut_validado)
                mensaje = Mensaje.objects.create(
                    titulo=titulo,
                    contenido=descripcion,
                    emisor=supervisor,
                    destinatario=destinatario
                )

                return redirect('home_administrador')
            except:
                try:
                    destinatario = Supervisor.objects.get(rut=rut_validado)
                    mensaje = Mensaje.objects.create(
                        titulo=titulo,
                        contenido=descripcion,
                        emisor=supervisor,
                        destinatario=destinatario
                    )

                    return redirect('home_administrador')
                except Exception as e:
                    error(e)
                    return redirect('home_administrador')     
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def enviar_mensaje_coordinador(request):
    if 'coordinador_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            try:
                destinatario = Directivo.objects.get(rut=rut_validado)
                mensaje = Mensaje.objects.create(
                    titulo=titulo,
                    contenido=descripcion,
                    emisor=coordinador,
                    destinatario=destinatario
                )

                return redirect('home_administrador')
            except:
                try:
                    destinatario = Coordinador.objects.get(rut=rut_validado)
                    mensaje = Mensaje.objects.create(
                        titulo=titulo,
                        contenido=descripcion,
                        emisor=coordinador,
                        destinatario=destinatario
                    )

                    return redirect('home_administrador')
                except:
                    try:
                        destinatario = Supervisor.objects.get(rut=rut_validado)
                        mensaje = Mensaje.objects.create(
                            titulo=titulo,
                            contenido=descripcion,
                            emisor=coordinador,
                            destinatario=destinatario
                        )

                        return redirect('home_administrador')
                    except Exception as e:
                        error(e)
                        return redirect('home_administrador')     
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def enviar_mensaje_directivo(request):
    if 'directivo_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            validar_rut = CLRutField()
            rut_validado = validar_rut.clean(rut)
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            
            try:
                destinatario = Directivo.objects.get(rut=rut_validado)
                mensaje = Mensaje.objects.create(
                    titulo=titulo,
                    contenido=descripcion,
                    emisor=directivo,
                    destinatario=destinatario
                )

                return redirect('home_administrador')
            except:
                try:
                    destinatario = Coordinador.objects.get(rut=rut_validado)
                    mensaje = Mensaje.objects.create(
                        titulo=titulo,
                        contenido=descripcion,
                        emisor=directivo,
                        destinatario=destinatario
                    )

                    return redirect('home_administrador')
                except Exception as e:
                    error(e)
                    return redirect('home_administrador')     
        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def buscar(request):
    if 'usuario_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            mensajes = Mensaje.objects.filter(destinatario=corredor)
            corredores = Corredor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

            data = {
                'usuarios': corredores,
                'corredor': corredor,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home.html', data)

        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')
    
def buscar_supervisor(request):
    if 'supervisor_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
            mensajes = Mensaje.objects.filter(destinatario=supervisor)
            corredores = Corredor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

            data = {
                'usuarios': corredores,
                'supervisor': supervisor,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home_supervisor.html', data)

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def buscar_coordinador(request):
    if 'coordinador_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])
            mensajes = Mensaje.objects.filter(destinatario=coordinador)
            supervisores = Supervisor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

            data = {
                'usuarios': supervisores,
                'coordinador': coordinador,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home_supervisor.html', data)

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')
    
def buscar_directivo(request):
    if 'directivo_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
            subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
            directivo = Directivo.objects.get(id=request.session['directivo_id'])
            mensajes = Mensaje.objects.filter(destinatario=directivo)

            data = {
                'directivo': directivo,
                'mensajes': mensajes,
                'subidas': subidas
            }

            return render(request, 'home_supervisor.html', data)

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('login_administrador')

def eliminar_subida(request, subida_id):
    if 'usuario_id' in request.session:
        corredor = Corredor.objects.get(id=request.session['usuario_id'])
        subida = Subida.objects.get(id=subida_id, corredor=corredor)
        documentos = Documento.objects.filter(subida=subida)

        try:
            for doc in documentos:
                doc.archivo.delete(save=False)

            logs = Log.objects.create(
                usuario=corredor,
                accion=f'Elimino una subida ({subida.id})'
            )

            subida.delete()

            return redirect('home')

        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')
    
def eliminar_subida_supervisor(request, subida_id):
    if 'supervisor_id' in request.session:
        supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            for doc in documentos:
                doc.archivo.delete(save=False)

            logs = Log.objects.create(
                usuario=supervisor,
                accion=f'Elimino una subida ({subida.id})'
            )

            subida.delete()

            return redirect('home_administrador')

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('index')

def registrar_administrador(request):
    if request.method == "POST":
        nombre_usuario = request.POST.get("nombre_usuario")
        apellido_usuario = request.POST.get("apellido_usuario")
        rut = request.POST.get("rut")
        correo = request.POST.get("correo")
        correo_confirmar = request.POST.get("correo_confirmar")
        contraseña = request.POST.get("contraseña")
        contraseña_confirmar = request.POST.get("contraseña_confirmar")
        tipo_administrador = request.POST.get("tipo_administrador")
        clave_nuam_ingresada = request.POST.get('clave_nuam')

        try:
            if correo == correo_confirmar and contraseña == contraseña_confirmar:
                if tipo_administrador == "supervisor" and verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    validar_rut = CLRutField()
                    rut_validado = validar_rut.clean(rut)
                    contraseña_hasheada = hashear_contraseña(contraseña)

                    supervisor = Supervisor.objects.create(
                        nombre_usuario=nombre_usuario,
                        apellido_usuario=apellido_usuario,
                        rut=rut_validado,
                        correo=correo,
                        contraseña=contraseña_hasheada
                    )

                    logs = Log.objects.create(
                        usuario=supervisor,
                        accion='Se creó el usuario'
                    )

                    data = {
                        'corredor': supervisor,
                        'mensaje': "Se ha registrado con éxito"
                    }

                    return render(request, 'login_administrador.html', data)
                elif tipo_administrador == "coordinador" and verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    validar_rut = CLRutField()
                    rut_validado = validar_rut.clean(rut)
                    contraseña_hasheada = hashear_contraseña(contraseña)

                    coordinador = Coordinador.objects.create(
                        nombre_usuario=nombre_usuario,
                        apellido_usuario=apellido_usuario,
                        rut=rut_validado,
                        correo=correo,
                        contraseña=contraseña_hasheada
                    )

                    logs = Log.objects.create(
                        usuario=coordinador,
                        accion='Se creó el usuario'
                    )

                    data = {
                        'corredor': coordinador,
                        'mensaje': "Se ha registrado con éxito"
                    }

                    return render(request, 'login_administrador.html', data)
                elif tipo_administrador == "directivo" and verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    validar_rut = CLRutField()
                    rut_validado = validar_rut.clean(rut)
                    contraseña_hasheada = hashear_contraseña(contraseña)

                    directivo = Directivo.objects.create(
                        nombre_usuario=nombre_usuario,
                        apellido_usuario=apellido_usuario,
                        rut=rut_validado,
                        correo=correo,
                        contraseña=contraseña_hasheada
                    )

                    logs = Log.objects.create(
                        usuario=directivo,
                        accion='Se creó el usuario'
                    )

                    data = {
                        'corredor': directivo,
                        'mensaje': "Se ha registrado con éxito"
                    }

                    return render(request, 'login_administrador.html', data)
                else:
                    data = {
                        'mensaje': "La clave nuam es incorrecta"
                    }

                    return render(request, 'login_administrador.html', data)
            else:
                data = {
                    'mensaje': "Ha ocurrido un error durante el registro"
                }

                return render(request, 'login_administrador.html', data)
        except Exception as e:
            error(e)

            data = {
                'mensaje': "Ha ocurrido un error durante el registro"
            }

            return render(request, 'login_administrador.html', data)
    else:
        return redirect("login_administrador")

def ingresar_administrador(request):
    if request.method == "GET":
        rut = request.GET.get('rut')
        contraseña = request.GET.get('contraseña')
        clave_nuam_ingresada = request.GET.get('clave_nuam')

        try:
            validar_rut = CLRutField()
            rut = validar_rut.clean(rut)
            supervisor = Supervisor.objects.get(rut=rut)
            if verificar_contraseña(contraseña, supervisor.contraseña):
                if verificar_contraseña(clave_nuam_ingresada, clave_nuam_supervisor):
                    request.session['supervisor_id'] = supervisor.id
                    request.session.modified = True

                    logs = Log.objects.create(
                        usuario=supervisor,
                        accion='Inició sesión'
                    )

                    return redirect('home_administrador')
                else:
                    data = {
                        'mensaje': "Los datos no son correctos"
                    }
                    return render(request, 'login_administrador.html', data)
            else:
                data = {
                        'mensaje': "Los datos no son correctos"
                }
                return render(request, 'login_administrador.html', data)
        except:
            try:
                validar_rut = CLRutField()
                rut = validar_rut.clean(rut)
                coordinador = Coordinador.objects.get(rut=rut)
                if verificar_contraseña(contraseña, coordinador.contraseña):
                    if verificar_contraseña(clave_nuam_ingresada, clave_nuam_coordinador):
                        request.session['coordinador_id'] = coordinador.id
                        request.session.modified = True

                        logs = Log.objects.create(
                            usuario=coordinador,
                            accion='Inició sesión'
                        )

                        return redirect('home_administrador')
                    else:
                        data = {
                            'mensaje': "Los datos no son correctos"
                        }
                        return render(request, 'login_administrador.html', data)
                else:
                    data = {
                        'mensaje': "Los datos no son correctos"
                    }
                    return render(request, 'login_administrador.html', data)
            except:
                try:
                    validar_rut = CLRutField()
                    rut = validar_rut.clean(rut)
                    directivo = Directivo.objects.get(rut=rut)
                    if verificar_contraseña(contraseña, directivo.contraseña):
                        if verificar_contraseña(clave_nuam_ingresada, clave_nuam_directivo):
                            request.session['directivo_id'] = directivo.id
                            request.session.modified = True

                            logs = Log.objects.create(
                                usuario=directivo,
                                accion='Inició sesión'
                            )

                            return redirect('home_administrador')
                        else:
                            data = {
                                'mensaje': "Los datos no son correctos"
                            }
                            return render(request, 'login_administrador.html', data)
                    else:
                        data = {
                            'mensaje': "Los datos no son correctos"
                        }
                        return render(request, 'login_administrador.html', data)
                except:
                    data = {
                        'mensaje': "Los datos ingresados no coinciden con ninguna cuenta registrada"
                    }
                    return render(request, 'login_administrador.html', data)
    else:
        return redirect('login_administrador')
    
def salir_administrador(request):
    if 'supervisor_id' in request.session:

        supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])

        logs = Log.objects.create(
            usuario=supervisor,
            accion='Salió de la sesión'
        )

        log_out(request)
        return redirect('login_administrador')
    elif 'coordinador_id' in request.session:

        coordinador = Coordinador.objects.get(id=request.session['coordinador_id'])

        logs = Log.objects.create(
            usuario=coordinador,
            accion='Salió de la sesión'
        )

        log_out(request)
        return redirect('login_administrador')
    elif 'directivo_id' in request.session:
        
        directivo = Directivo.objects.get(id=request.session['directivo_id'])

        logs = Log.objects.create(
            usuario=directivo,
            accion='Salió de la sesión'
        )

        log_out(request)
        return redirect('login_administrador')
    else:
        return redirect('login_administrador')

def aprobar(request, subida_id):
    if 'supervisor_id' in request.session:
        supervisor = Supervisor.objects.get(id=request.session['supervisor_id'])
        subida = Subida.objects.get(id=subida_id)

        try:
            logs = Log.objects.create(
                usuario=supervisor,
                accion=f'Aprovó una subida ({subida.id})'
            )

            subida.estado = 'Aceptado'
            subida.save()

            return redirect('home_administrador')

        except Exception as e:
            error(e)
            return redirect('home_administrador')
    else:
        return redirect('index')
    
def crear_documento(request):
    if 'usuario_id' in request.session:
        titulo = request.POST.get("titulo")
        tipo_subida = request.POST.get("tipo_subida")
        mercado = request.POST.get("mercado")
        instrumento = request.POST.get("instrumento")
        descripcion = request.POST.get("descripcion")
        fecha_pago = request.POST.get("fecha_pago")
        secuencia_evento = request.POST.get("secuencia_evento")
        dividendo = request.POST.get("dividendo")
        valor_historico = request.POST.get("valor_historico")
        factor_actualizacion = request.POST.get("factor_actualizacion")
        año = request.POST.get("año")
        isfut = request.POST.get("isfut")

        factor_8 = request.POST.get("factor_8")
        factor_9 = request.POST.get("factor_9")
        factor_10 = request.POST.get("factor_10")
        factor_11 = request.POST.get("factor_11")
        factor_12 = request.POST.get("factor_12")
        factor_13 = request.POST.get("factor_13")
        factor_14 = request.POST.get("factor_14")
        factor_15 = request.POST.get("factor_15")
        factor_16 = request.POST.get("factor_16")
        factor_17 = request.POST.get("factor_17")
        factor_18 = request.POST.get("factor_18")
        factor_19 = request.POST.get("factor_19")
        factor_20 = request.POST.get("factor_20")
        factor_21 = request.POST.get("factor_21")
        factor_22 = request.POST.get("factor_22")
        factor_23 = request.POST.get("factor_23")
        factor_24 = request.POST.get("factor_24")
        factor_25 = request.POST.get("factor_25")
        factor_26 = request.POST.get("factor_26")
        factor_27 = request.POST.get("factor_27")
        factor_28 = request.POST.get("factor_28")
        factor_29 = request.POST.get("factor_29")
        factor_30 = request.POST.get("factor_30")
        factor_31 = request.POST.get("factor_31")
        factor_32 = request.POST.get("factor_32")
        factor_33 = request.POST.get("factor_33")
        factor_34 = request.POST.get("factor_34")
        factor_35 = request.POST.get("factor_35")
        factor_36 = request.POST.get("factor_36")
        factor_37 = request.POST.get("factor_37")

        campos = [titulo, tipo_subida, mercado, instrumento, descripcion, fecha_pago, secuencia_evento, dividendo, valor_historico, factor_actualizacion, año, isfut, factor_8,
                  factor_9, factor_10, factor_11, factor_12, factor_13, factor_14, factor_15, factor_16, factor_17, factor_18, factor_19, factor_20, factor_21, factor_22,
                  factor_23, factor_24, factor_25, factor_26, factor_27, factor_28, factor_29, factor_30, factor_31, factor_32, factor_33, factor_34, factor_35, factor_36,
                  factor_37]
        
        factores = [factor_8, factor_9, factor_10, factor_11, factor_12, factor_13, factor_14, factor_15, factor_16, factor_17, factor_18, factor_19, factor_20, factor_21,
                    factor_22, factor_23, factor_24, factor_25, factor_26, factor_27, factor_28, factor_29, factor_30, factor_31, factor_32, factor_33, factor_34, factor_35,
                    factor_36, factor_37]

        factores_decimales = [Decimal(factor) for factor in factores]

        try:
            if not any(campo == '' for campo in campos):
                if any(factor <= 1 for factor in factores_decimales):
                    corredor = Corredor.objects.get(id=request.session['usuario_id'])

                    pdf = FPDF(orientation='L')
                    pdf.add_page()
                    pdf.set_font('Arial', 'B', 11)

                    pdf.cell(50, 10, text='Mercado', border=1, align='C')
                    pdf.cell(50, 10, text='Instrumento', border=1, align='C')
                    pdf.cell(75, 10, text='Descripción', border=1, align='C')
                    pdf.cell(40, 10, text='Fecha de pago', border=1, align='C')
                    pdf.cell(40, 10, text='Secuencia evento', border=1, align='C', ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(50, 10, text= mercado, border=1)
                    pdf.cell(50, 10, text= instrumento, border=1)
                    pdf.cell(75, 10, text= descripcion, border=1)
                    pdf.cell(40, 10, text= fecha_pago, border=1)
                    pdf.cell(40, 10, text= secuencia_evento, border=1, ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text='Dividendo', border=1, align='C')
                    pdf.cell(40, 10, text='Valor histórico', border=1, align='C')
                    pdf.cell(40, 10, text='Factor actualización', border=1, align='C')
                    pdf.cell(40, 10, text='Año', border=1, align='C')
                    pdf.cell(40, 10, text='ISFUT', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 8', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 9', border=1, align='C', ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text= dividendo, border=1)
                    pdf.cell(40, 10, text= valor_historico, border=1)
                    pdf.cell(40, 10, text= factor_actualizacion, border=1)
                    pdf.cell(40, 10, text= año, border=1)
                    pdf.cell(40, 10, text= isfut, border=1)
                    pdf.cell(40, 10, text= factor_8, border=1)
                    pdf.cell(40, 10, text= factor_9, border=1, ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text='Factor 10', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 11', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 12', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 13', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 14', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 15', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 16', border=1, align='C', ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text= factor_10, border=1)
                    pdf.cell(40, 10, text= factor_11, border=1)
                    pdf.cell(40, 10, text= factor_12, border=1)
                    pdf.cell(40, 10, text= factor_13, border=1)
                    pdf.cell(40, 10, text= factor_14, border=1)
                    pdf.cell(40, 10, text= factor_15, border=1)
                    pdf.cell(40, 10, text= factor_16, border=1, ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text='Factor 17', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 18', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 19', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 20', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 21', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 22', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 23', border=1, align='C', ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text= factor_17, border=1)
                    pdf.cell(40, 10, text= factor_18, border=1)
                    pdf.cell(40, 10, text= factor_19, border=1)
                    pdf.cell(40, 10, text= factor_20, border=1)
                    pdf.cell(40, 10, text= factor_21, border=1)
                    pdf.cell(40, 10, text= factor_22, border=1)
                    pdf.cell(40, 10, text= factor_23, border=1, ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text='Factor 24', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 25', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 26', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 27', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 28', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 29', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 30', border=1, align='C', ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text= factor_24, border=1)
                    pdf.cell(40, 10, text= factor_25, border=1)
                    pdf.cell(40, 10, text= factor_26, border=1)
                    pdf.cell(40, 10, text= factor_27, border=1)
                    pdf.cell(40, 10, text= factor_28, border=1)
                    pdf.cell(40, 10, text= factor_29, border=1)
                    pdf.cell(40, 10, text= factor_30, border=1, ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text='Factor 31', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 32', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 33', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 34', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 35', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 36', border=1, align='C')
                    pdf.cell(40, 10, text='Factor 37', border=1, align='C', ln=True)

                    pdf.set_font('Arial', '', 11)

                    pdf.cell(40, 10, text= factor_31, border=1)
                    pdf.cell(40, 10, text= factor_32, border=1)
                    pdf.cell(40, 10, text= factor_33, border=1)
                    pdf.cell(40, 10, text= factor_34, border=1)
                    pdf.cell(40, 10, text= factor_35, border=1)
                    pdf.cell(40, 10, text= factor_36, border=1)
                    pdf.cell(40, 10, text= factor_37, border=1)

                    pdf_output = pdf.output(dest='S')
                    
                    subida = Subida.objects.create(
                        titulo=titulo,
                        descripcion=descripcion,
                        tipo_subida=tipo_subida,
                        mercado=mercado,
                        instrumento=instrumento,
                        fecha_pago=fecha_pago,
                        secuencia_evento=secuencia_evento,
                        dividendo=dividendo,
                        valor_historico=valor_historico,
                        factor_actualizacion=factor_actualizacion,
                        año=año,
                        isfut=isfut,
                        factor_8=factor_8,
                        factor_9=factor_9,
                        factor_10=factor_10,
                        factor_11=factor_11,
                        factor_12=factor_12,
                        factor_13=factor_13, 
                        factor_14=factor_14,
                        factor_15=factor_15,
                        factor_16=factor_16,
                        factor_17=factor_17,
                        factor_18=factor_18,
                        factor_19=factor_19,
                        factor_20=factor_20,
                        factor_21=factor_21,
                        factor_22=factor_22,
                        factor_23=factor_23,
                        factor_24=factor_24,
                        factor_25=factor_25,
                        factor_26=factor_26,
                        factor_27=factor_27,
                        factor_28=factor_28,
                        factor_29=factor_29,
                        factor_30=factor_30,
                        factor_31=factor_31,
                        factor_32=factor_32,
                        factor_33=factor_33,
                        factor_34=factor_34,
                        factor_35=factor_35,
                        factor_36=factor_36,
                        factor_37=factor_37,
                        corredor=corredor
                    )

                    documento_pdf = ContentFile(pdf_output, name=f'calificacion_{subida.id}.pdf')

                    documento = Documento.objects.create(
                        archivo=documento_pdf,
                        subida=subida
                    )
                    return redirect('home')
            else:
                return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')