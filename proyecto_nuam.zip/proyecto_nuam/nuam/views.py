import os
from io import BytesIO
import zipfile
from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect
import bcrypt
from .models import Corredor, Documento, Subida, Mensaje
from django.contrib.auth import logout as log_out
from datetime import datetime

def error(e):
    print(f"ERROR: {e}")

def hashear_contraseña(contraseña):
    sal_generada = bcrypt.gensalt()
    hash_resultante = bcrypt.hashpw(contraseña.encode('utf-8'), sal_generada)
    return hash_resultante

def verificar_contraseña(contraseña, hash_almacenado):
    contraseña_bytes = contraseña.encode('utf-8')
    return bcrypt.checkpw(contraseña_bytes, hash_almacenado)

def is_valid_extension(archivo):
    valid_extensions = ['.pdf']
    if not archivo:
        return True 
    
    ext = os.path.splitext(archivo.name)[1]
    return ext.lower() in valid_extensions

# Create your views here.

def index(request):
    return render(request, 'index.html')

def registrar_corredor(request):
    if request.method == "POST":
        nombre_usuario = request.POST.get("nombre_usuario")
        apellido_usuario = request.POST.get("apellido_usuario")
        rut = request.POST.get("rut")
        correo = request.POST.get("correo")
        correo_confirmar = request.POST.get("correo_confirmar")
        contraseña = request.POST.get("contraseña")
        contraseña_confirmar = request.POST.get("contraseña_confirmar")
    
        try:
            if correo == correo_confirmar and contraseña == contraseña_confirmar:
                contraseña_hasheada = hashear_contraseña(contraseña)

                corredor = Corredor.objects.create(
                    nombre_usuario=nombre_usuario,
                    apellido_usuario=apellido_usuario,
                    rut=rut,
                    correo=correo,
                    contraseña=contraseña_hasheada
                )

                data = {
                    'corredor': corredor,
                    'mensaje': "Se ha registrado con éxito"
                }

                return render(request, 'index.html', data)
            else:
                data = {
                    'mensaje': "Ha ocurrido un error durante el registro"
                }

                return render(request, 'index.html', data)

        except Exception as e:
            error(e)

            data = {
                'mensaje': "Ha ocurrido un error durante el registro"
            }

            return render(request, 'index.html', data)
    
    else:
        return redirect("index")

def ingresar_corredor(request):
    if request.method == "GET":
        rut = request.GET.get("rut")
        contraseña = request.GET.get("contraseña")

        try:

            corredor = Corredor.objects.get(rut=rut)

            if verificar_contraseña(contraseña, corredor.contraseña):
                request.session['usuario_id'] = corredor.id
                request.session.modified = True

                return redirect('home')
            else:
                data = {
                    'mensaje': "Los datos ingresados no coinciden con ninguna cuenta registrada"
                }
                return render(request, 'index.html', data)    

        except Exception as e:
            error(e)
            data = {
                'mensaje': "Ha ocurrido un error durante el ingreso"
            }
            return render(request, 'index.html', data)
        
    else:
        return redirect('index')

def home(request):
    if 'usuario_id' in request.session:
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            subidas = Subida.objects.filter().order_by('-id').prefetch_related('documento_set')
            subidas_corredor = Subida.objects.filter(corredor=corredor).order_by('-id').prefetch_related('documento_set')
            mensajes = Mensaje.objects.filter(destinatario=corredor)
            usuarios = Corredor.objects.filter().order_by('-id')

            data = {
                'corredor': corredor,
                'subidas': subidas,
                'subidas_corredor': subidas_corredor,
                'mensajes': mensajes,
                'usuarios': usuarios
            }

            return render(request, 'home.html', data)
        except Exception as e:
            error(e)
            return redirect('index')
    else:
        return redirect('index')

def salir(request):
    if 'usuario_id' in request.session:
        log_out(request)
        return redirect('index')
    else:
        return redirect('index')
    
def subir_documentos(request):
    if 'usuario_id' in request.session:
        titulo = request.POST.get("titulo")
        descripcion = request.POST.get("descripcion")
        tipo_subida = request.POST.get("tipo_subida")
        archivo = request.FILES.getlist("archivo[]")
        
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            if archivo:
                for file in archivo:
                    if file and not is_valid_extension(file):
                        print("El archivo no es valido")
                        return redirect('home')
                subida = Subida.objects.create(titulo=titulo, descripcion=descripcion, tipo_subida=tipo_subida, corredor=corredor)
                for file in archivo:
                    if file and not is_valid_extension(file):
                        print("El archivo no es valido")
                        return redirect('home')
                    else:
                        documento = Documento.objects.create(archivo=file, subida=subida)
                        documento.save()
                return redirect('home')
            else:                
                return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def descargar_subida(request, subida_id):
    if 'usuario_id' in request.session:
        subida = Subida.objects.get(id=subida_id)
        documentos = Documento.objects.filter(subida=subida)

        try:
            buffer = BytesIO()
            with zipfile.ZipFile(buffer, 'w') as zip_file:
                for doc in documentos:
                    ruta_relativa = doc.archivo.name
                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                    if os.path.exists(ruta_archivo):
                        zip_file.write(
                            ruta_archivo, 
                            arcname=doc.archivo.name
                        )
            buffer.seek(0)

            response = HttpResponse(buffer.read())
            response['Content-Type'] = 'application/zip'
            response['Content-Disposition'] = f'attachment; filename="documentos_{subida_id}.zip"'

            return response
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def descargar_subidas(request):
    if 'usuario_id' in request.session:
        titulos_subidas = request.GET.getlist('titulos[]')

        if titulos_subidas:
            try:
                master_buffer = BytesIO()
                with zipfile.ZipFile(master_buffer, 'w') as master_zip:
                    for titulo in titulos_subidas:
                        try:
                            subida = Subida.objects.get(titulo=titulo)
                            documentos = Documento.objects.filter(subida=subida)

                            if not documentos.exists():
                                continue
                            inner_buffer = BytesIO()
                            with zipfile.ZipFile(inner_buffer, 'w') as inner_zip:
                                for doc in documentos:
                                    ruta_relativa = doc.archivo.name
                                    ruta_archivo = os.path.join(settings.MEDIA_ROOT, ruta_relativa)

                                    if os.path.exists(ruta_archivo):
                                        inner_zip.write(
                                            ruta_archivo, 
                                            arcname=os.path.basename(ruta_relativa)
                                        )
                            inner_buffer.seek(0)
                            master_zip.writestr(
                                f"documentos_{subida.titulo}.zip",inner_buffer.read())
                            inner_buffer.close()

                        except Subida.DoesNotExist:
                            print(f"Advertencia: No se encontró la subida con el título '{titulo}'.")
                tiempo = datetime.now()
                master_buffer.seek(0)
                response = HttpResponse(master_buffer.read())
                response['Content-Type'] = 'application/zip'
                response['Content-Disposition'] = f'attachment; filename="Subidas_Seleccionadas{tiempo}.zip"' 

                return response
            except Exception as e:
                print(f"ERROR: {e}") 
                return redirect('home')
        else:
            return redirect('home')
    else:
        return redirect('index')

def corredor_subidas(request):
    if 'usuario_id' in request.session:
        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            subidas = Subida.objects.filter(corredor=corredor).order_by('-id')
            mensajes = Mensaje.objects.filter(destinatario=corredor)

            data = {
                'corredor':corredor,
                'subidas':subidas,
                'mensajes':mensajes
            }

            return render(request, 'corredor_subidas.html', data)
        except Exception as e:
            error(e)
            return redirect('index')
    else:
        return redirect('index')

def enviar_mensaje(request):
    if 'usuario_id' in request.session:
        rut = request.POST.get('rut')
        titulo = request.POST.get('titulo')
        descripcion = request.POST.get('descripcion')

        try:
            corredor = Corredor.objects.get(id=request.session['usuario_id'])
            destinatario = Corredor.objects.get(rut=rut)

            mensaje = Mensaje.objects.create(
                titulo=titulo,
                contenido=descripcion,
                emisor=corredor,
                destinatario=destinatario
            )

            return redirect('home')
        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def buscar(request):
    if 'usuario_id' in request.session:
        input_buscar = request.GET.get('input_buscar')

        try:
                subidas = Subida.objects.filter(titulo__icontains = input_buscar).order_by('-id')
                corredor = Corredor.objects.get(id=request.session['usuario_id'])
                mensajes = Mensaje.objects.filter(destinatario=corredor)
                corredores = Corredor.objects.filter(nombre_usuario__icontains = input_buscar).order_by('-id')

                data = {
                    'usuarios':corredores,
                    'corredor':corredor,
                    'mensajes':mensajes,
                    'subidas':subidas
                }

                return render(request, 'home.html', data)

        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')

def eliminar_subida(request, subida_id):
    if 'usuario_id' in request.session:
        corredor = Corredor.objects.get(id=request.session['usuario_id'])
        subida = Subida.objects.get(id=subida_id, corredor=corredor)
        documentos = Documento.objects.filter(subida=subida)

        try:
            for doc in documentos:
                doc.archivo.delete(save=False)
            
            subida.delete()
            return redirect('home')

        except Exception as e:
            error(e)
            return redirect('home')
    else:
        return redirect('index')