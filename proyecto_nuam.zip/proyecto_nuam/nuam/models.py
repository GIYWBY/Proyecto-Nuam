from django.db import models
import os
from django.core.exceptions import ValidationError
from django.utils import timezone

def validate_image_extension(value):
    ext = os.path.splitext(value.name)[1]
    valid_extensions = ['.pdf', '.csv']
    if not ext.lower() in valid_extensions:
        raise ValidationError('Formato de archivo no soportado')

# Create your models here.

class Usuario(models.Model):
    nombre_usuario = models.CharField(max_length=30, null=False, blank=False)
    apellido_usuario = models.CharField(max_length=30, null=False, blank=False)
    rut = models.CharField(max_length=13, null=False, blank=False, unique=True)
    correo = models.EmailField(null=False, blank=False, unique=True)
    contraseña = models.BinaryField(max_length=50, null=False, blank=False, unique=True)
    departamento = models.CharField(max_length=30, null=True, default="por asignar")
    rol_empleado = models.CharField(max_length=30, null=True, default="por asignar")
    fecha_creacion = models.DateField(auto_now_add=True)

class Directivo(Usuario):
    pass

class Coordinador(Usuario):
    pass

class Supervisor(Usuario):
    id_coordinador = models.OneToOneField(Coordinador, null=True, blank=False, on_delete=models.CASCADE)

class Corredor(Usuario):
    id_supervisor = models.OneToOneField(Supervisor, null=True, blank=False, on_delete=models.CASCADE)

class Subida(models.Model):
    titulo = models.CharField(max_length=20, null=False, blank=False, unique=True)
    descripcion = models.TextField(max_length=20, null=True)
    fecha_subida = models.DateField(auto_now_add=True)
    tipo_subida = models.CharField(max_length=20, null=False, blank=False)
    mercado = models.CharField(max_length=20,null=False, blank=False)
    instrumento = models.CharField(max_length=20,null=False, blank=False)
    fecha_pago = models.DateField(default=timezone.now)
    secuencia_evento = models.IntegerField(null=False, blank=False)
    dividendo = models.IntegerField(null=False, blank=False, default=0)
    valor_historico = models.IntegerField(null=False, blank=False)
    factor_actualizacion = models.IntegerField(null=False, blank=False)
    año = models.CharField(max_length=4, null=False, blank=False)
    isfut = models.CharField(max_length=2, null=False, blank=False, default="no")
    factor_8 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_9 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_10 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_11 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_12 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_13 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_14 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_15 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_16 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_17 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_18 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_19 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_20 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_21 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_22 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_23 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_24 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_25 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_26 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_27 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_28 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_29 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_30 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_31 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_32 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_33 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_34 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_35 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_36 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    factor_37 = models.DecimalField(max_digits=9, decimal_places=8, null=False, blank=False)
    corredor = models.ForeignKey(Corredor, null=False, blank=False, on_delete=models.CASCADE)
    estado = models.CharField(max_length=20, null=False, default="Revisión")

class Documento(models.Model):
    archivo = models.FileField(validators=[validate_image_extension], null=False, blank=False, unique=True)
    fecha_subida = models.DateField(auto_now_add=True)
    subida = models.ForeignKey(Subida, null=False, blank=False, on_delete=models.CASCADE)

class Mensaje(models.Model):
    titulo = models.CharField(max_length=30, null=False, blank=False)
    contenido = models.TextField(max_length=500, null=True, blank=True)
    emisor = models.ForeignKey(Usuario, related_name="mensaje_emisor", null=False, blank=False, on_delete=models.CASCADE)
    destinatario = models.ForeignKey(Usuario, related_name="mensaje_destinatario", null=False, blank=False, on_delete=models.CASCADE)
    fecha_envio = models.DateTimeField(default=timezone.now)

class Log(models.Model):
    usuario = models.ForeignKey(Usuario, null=False, blank=False, on_delete=models.CASCADE)
    accion = models.TextField(null=True, blank=True)
    fecha_accion = models.DateTimeField(default=timezone.now)