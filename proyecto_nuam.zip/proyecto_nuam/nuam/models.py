from django.db import models
import os
from django.core.exceptions import ValidationError
from django.utils import timezone
from localflavor.cl import forms

def validate_image_extension(value):
    ext = os.path.splitext(value.name)[1]
    valid_extensions = ['.pdf', '.xlsx']
    if not ext.lower() in valid_extensions:
        raise ValidationError('Formato de archivo no soportado')

# Create your models here.

class Usuario(models.Model):
    nombre_usuario = models.CharField(max_length=30, null=False, blank=False)
    apellido_usuario = models.CharField(max_length=30, null=False, blank=False)
    rut = forms.CLRutField()
    correo = models.EmailField(null=False, blank=False, unique=True)
    contraseña = models.BinaryField(max_length=50, null=False, blank=False, unique=True)
    departamento = models.CharField(max_length=30, null=True, default="por asignar")
    rol_empleado = models.CharField(max_length=30, null=True, default="por asignar")
    fecha_creacion = models.DateField(auto_now_add=True)

class Directivo(Usuario):
    descripcion = models.TextField(max_length=500, null=True)

class Coordinador(Usuario):
    descripcion = models.TextField(max_length=500, null=True)

class Supervisor(Usuario):
    id_coordinador = models.OneToOneField(Coordinador, null=True, blank=False, on_delete=models.CASCADE)
    descripcion = models.TextField(max_length=500, null=True)

class Corredor(Usuario):
    id_supervisor = models.OneToOneField(Supervisor, null=True, blank=False, on_delete=models.CASCADE)
    descripcion = models.TextField(max_length=500, null=True)

class Subida(models.Model):
    titulo = models.CharField(max_length=30, null=False, blank=False, unique=True)
    descripcion = models.TextField(max_length=500, null=True)
    fecha_subida = models.DateField(auto_now_add=True)
    tipo_subida = models.CharField(max_length=30, null=False, blank=False)
    corredor = models.ForeignKey(Corredor, null=False, blank=False, on_delete=models.CASCADE)

class Documento(models.Model):
    archivo = models.FileField(validators=[validate_image_extension], null=False, blank=False, unique=True)
    fecha_subida = models.DateField(auto_now_add=True)
    subida = models.ForeignKey(Subida, null=False, blank=False, on_delete=models.CASCADE)

class Mensaje(models.Model):
    titulo = models.CharField(max_length=30, null=False, blank=False)
    contenido = models.TextField(max_length=500, null=True, blank=True)
    emisor = models.ForeignKey(Usuario, related_name="mensaje_emisor", null=False, blank=False, on_delete=models.CASCADE)
    destinatario = models.ForeignKey(Usuario, related_name="mensaje_destinatario", null=False, blank=False, on_delete=models.CASCADE)
    fecha_envio = models.DateTimeField(default=timezone.now)