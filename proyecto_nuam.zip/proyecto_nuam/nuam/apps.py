from django.apps import AppConfig


class NuamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nuam'
