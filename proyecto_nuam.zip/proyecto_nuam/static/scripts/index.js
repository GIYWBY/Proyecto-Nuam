const logo = document.getElementById("logo")
const btn_registrar = document.getElementById("btn_registrar")
const div_login = document.getElementById("div_login")
const div_registro = document.getElementById("div_registro")
const btn_volver = document.getElementById("btn_volver")

setTimeout(function(){
    logo.style.animationName = ""
    logo.style.animationDuration = ""
    logo.style.animationFillMode = ""
    logo.style.width = "300px"

    logo.addEventListener("mouseover", function(){
        logo.style.animationName = "logo_hover"
        logo.style.animationDuration = "250ms"
        logo.style.animationFillMode = "forwards"
        logo.style.width = "350px"
    })

    logo.addEventListener("mouseout", function(){
        logo.style.animationName = "logo_hover_out"
        logo.style.animationDuration = "250ms"
        logo.style.animationFillMode = "forwards"
        logo.style.width = "300px"
    })
}, 1000)

let registrar = false

btn_registrar.addEventListener("click", function(){
    if(registrar == false){
        div_login.style.animationName = "div_login_no"
        div_login.style.animationDuration = "1000ms"
        div_login.style.animationFillMode = "forwards"

        div_registro.style.animationName = "div_registro_si"
        div_registro.style.animationDuration = "1500ms"
        div_registro.style.animationFillMode = "forwards"

        registrar = true
    }
})

btn_volver.addEventListener("click", function(){
    div_login.style.animationName = "div_login_si"
    div_login.style.animationDuration = "1500ms"
    div_login.style.animationFillMode = "forwards"

    div_registro.style.animationName = "div_registro_no"
    div_registro.style.animationDuration = "1000ms"
    div_registro.style.animationFillMode = "forwards"

    registrar = false
})