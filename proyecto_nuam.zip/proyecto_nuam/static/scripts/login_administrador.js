const btn_registrar = document.getElementById("btn_registrar")
const div_login = document.getElementById("div_login")
const div_registro = document.getElementById("div_registro")
const btn_volver = document.getElementById("btn_volver")

let registrar = false

btn_registrar.addEventListener("click", function(){
    if(registrar == false){
        div_login.style.animationName = "div_login_no"
        div_login.style.animationDuration = "1000ms"
        div_login.style.animationFillMode = "forwards"

        div_registro.style.animationName = "div_registro_si"
        div_registro.style.animationDuration = "1500ms"
        div_registro.style.animationFillMode = "forwards"

        registrar = true
    }
})

btn_volver.addEventListener("click", function(){
    div_login.style.animationName = "div_login_si"
    div_login.style.animationDuration = "1500ms"
    div_login.style.animationFillMode = "forwards"

    div_registro.style.animationName = "div_registro_no"
    div_registro.style.animationDuration = "1000ms"
    div_registro.style.animationFillMode = "forwards"

    registrar = false
})

const tipo_administrador = document.getElementById("tipo_administrador")
const btn_tipo_supervisor = document.getElementById("btn_tipo_supervisor")
const btn_tipo_coordinador = document.getElementById("btn_tipo_coordinador")
const btn_tipo_directivo = document.getElementById("btn_tipo_directivo")

btn_tipo_supervisor.addEventListener("click", function(){
    btn_tipo_supervisor.style.backgroundColor = "rgb(255, 115, 73)"
    btn_tipo_coordinador.style.backgroundColor = "white"
    btn_tipo_directivo.style.backgroundColor = "white"

    tipo_administrador.value = "supervisor"
})

btn_tipo_coordinador.addEventListener("click", function(){
    btn_tipo_coordinador.style.backgroundColor = "rgb(255, 115, 73)"
    btn_tipo_directivo.style.backgroundColor = "white"
    btn_tipo_supervisor.style.backgroundColor = "white"

    tipo_administrador.value = "coordinador"
})

btn_tipo_directivo.addEventListener("click", function(){
    btn_tipo_directivo.style.backgroundColor = "rgb(255, 115, 73)"
    btn_tipo_coordinador.style.backgroundColor = "white"
    btn_tipo_supervisor.style.backgroundColor = "white"

    tipo_administrador.value = "directivo"
})