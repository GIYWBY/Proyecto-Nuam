const btn_filtro_docs = document.getElementById("btn_filtro_docs")
const btn_filtro_users = document.getElementById("btn_filtro_users")
const tipo_busqueda = document.getElementById("tipo_busqueda")
const div_tabla_documentos = document.getElementById("div_tabla_documentos")
const div_tabla_usuarios = document.getElementById("div_tabla_usuarios")

div_tabla_usuarios.style.display = "none"

btn_filtro_docs.addEventListener("click", function(){
        btn_filtro_docs.className = "btn_filtro_activado"

        div_tabla_documentos.style.display = "block"
        div_tabla_usuarios.style.display = "none"

        btn_filtro_users.className = "btn_filtro_desactivado"
})

btn_filtro_users.addEventListener("click", function(){
    btn_filtro_users.className = "btn_filtro_activado"

    div_tabla_usuarios.style.display = "block"
    div_tabla_documentos.style.display = "none"

    btn_filtro_docs.className = "btn_filtro_desactivado"
})

const btn_checkbox = document.querySelectorAll('.btn_checkbox')
const box_seleccionar = document.querySelectorAll('.box_seleccionar')
const lista_archivos_descargar = document.getElementById("lista_archivos_descargar")

btn_checkbox.forEach(boton => {
    let estado = false
    boton.addEventListener("click", function(){
        if(estado == false){
            boton.className = "btn_checkbox_checked"

            const box_seleccionar_hidden = boton.previousElementSibling
            box_seleccionar_hidden.click()

            estado = true
        }else {
            boton.className = "btn_checkbox"

            const box_seleccionar_hidden = boton.previousElementSibling
            box_seleccionar_hidden.click()

            estado = false
        }
    })
})

box_seleccionar.forEach(boton => {
    boton.addEventListener("change", function(){
        if(boton.checked){
            const padre = boton.parentElement
            const abuelo = padre.parentElement
            const cerca = abuelo.firstChild
            const titulo = cerca.nextSibling
            const titulo_subida = document.createElement("li")
            const input_titulo = document.createElement("input")

            titulo_subida.className = "titulo_subida_lista"
            titulo_subida.textContent = titulo.textContent

            input_titulo.type = "hidden"
            input_titulo.name = "titulos[]"
            input_titulo.value = titulo.textContent

            lista_archivos_descargar.appendChild(titulo_subida)
            lista_archivos_descargar.appendChild(input_titulo)

            this.titulo_subida_li = titulo_subida
            this.input_titulo_li = input_titulo
        }else{
            this.titulo_subida_li.remove()
            this.titulo_subida_li = null
            this.input_titulo_li.remove()
            this.input_titulo_li = null
        }
    })
})

const btn_mensaje = document.getElementById('btn_mensaje')
const div_fondo_mensaje_enviar = document.getElementById("div_fondo_mensaje_enviar")

btn_mensaje.addEventListener("click", function(){
    div_fondo_mensaje_enviar.style.display = "grid"
})

const btn_cerrar_mensaje = document.getElementById("btn_cerrar_mensaje")

btn_cerrar_mensaje.addEventListener("click", function(){
    div_fondo_mensaje_enviar.style.display = "none"
})

const btn_desplegar_mensajes = document.getElementById('btn_desplegar_mensajes')
const lista_mensajes = document.getElementById('lista_mensajes')

let desplegar = false

btn_desplegar_mensajes.addEventListener("click", function(){
    if(desplegar == false) {
        btn_desplegar_mensajes.style.animationName = "btn_desplegar"
        btn_desplegar_mensajes.style.animationFillMode = "forwards"
        btn_desplegar_mensajes.style.animationDuration = "250ms"
        lista_mensajes.style.display = "grid"
        desplegar = true
    }else {
        btn_desplegar_mensajes.style.animationName = "btn_desplegar_volver"
        btn_desplegar_mensajes.style.animationFillMode = "forwards"
        btn_desplegar_mensajes.style.animationDuration = "250ms"
        lista_mensajes.style.display = "none"
        desplegar = false
    }
})

const div_fondo_mensajes_recibidos = document.querySelectorAll(".div_fondo_mensajes_recibidos")
const btn_mensaje_recibido = document.querySelectorAll(".btn_mensaje_recibido")

div_fondo_mensajes_recibidos.forEach(div_fondo => {
    const div_mensajes_recibidos = div_fondo.querySelector(".div_mensajes_recibidos")
    const btn_cerrar_form = div_mensajes_recibidos.querySelector(".btn_cerrar_form")
    const input_oculto_id_mensaje = div_mensajes_recibidos.querySelector(".input_oculto_id_mensaje")

    btn_cerrar_form.addEventListener("click", function(){
        div_fondo.style.display = "none"
    })

    btn_mensaje_recibido.forEach(boton => {
        const input_id_mensaje_oculto = boton.previousElementSibling
        boton.addEventListener("click", function(){
            if(input_id_mensaje_oculto.value == input_oculto_id_mensaje.value){
                div_fondo.style.display = "grid"
            }
        })
    })
})

const botones_cancelar_eliminar = document.querySelectorAll(".btn_cancelar")

botones_cancelar_eliminar.forEach(boton => {
    const botones_aceptar_cancelar = boton.parentElement
    const div_subida_eliminar = botones_aceptar_cancelar.parentElement
    const div_fondo_subida_eliminar = div_subida_eliminar.parentElement
    
    boton.addEventListener("click", function(){
        div_fondo_subida_eliminar.style.display = "none"
    })
})

const btn_eliminar = document.querySelectorAll(".btn_eliminar")
const div_fondos_subidas_eliminar = document.querySelectorAll(".div_fondo_subida_eliminar")

btn_eliminar.forEach(boton => {
    const input_subida_oculto = boton.nextElementSibling
    boton.addEventListener("click", function(){
        div_fondos_subidas_eliminar.forEach(div => {
            const input_subida_eliminar = div.querySelector(".input_subida_eliminar")
            if(input_subida_eliminar.value == input_subida_oculto.value){
                div.style.display = "grid"
            }
        })
    })  
})

const btn_log = document.getElementById("btn_log")
const div_fondo_logs = document.getElementById("div_fondo_logs")

btn_log.addEventListener("click", function(){
    div_fondo_logs.style.display = "grid"
})

const btn_cerrar_logs = document.getElementById("btn_cerrar_logs")

btn_cerrar_logs.addEventListener("click", function(){
    div_fondo_logs.style.display = "none"
})

const btn_estado = document.querySelectorAll(".btn_estado")
const div_fondo_revisar = document.querySelectorAll(".div_fondo_revisar")

btn_estado.forEach(boton => {
    const input_subida_oculto = boton.nextElementSibling
    boton.addEventListener("click", function(){
        div_fondo_revisar.forEach(div => {
            const input_subida_revisar = div.querySelector(".input_subida_revisar")
            if(input_subida_revisar.value == input_subida_oculto.value){
                div.style.display = "grid"
            }
        })
    })
})