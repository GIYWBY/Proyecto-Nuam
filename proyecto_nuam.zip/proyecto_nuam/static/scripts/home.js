const btn_filtro_docs = document.getElementById("btn_filtro_docs")
const btn_filtro_users = document.getElementById("btn_filtro_users")
const tipo_busqueda = document.getElementById("tipo_busqueda")
const div_tabla_documentos = document.getElementById("div_tabla_documentos")
const div_tabla_usuarios = document.getElementById("div_tabla_usuarios")

div_tabla_usuarios.style.display = "none"

btn_filtro_docs.addEventListener("click", function(){
        btn_filtro_docs.className = "btn_filtro_activado"

        div_tabla_documentos.style.display = "block"
        div_tabla_usuarios.style.display = "none"

        btn_filtro_users.className = "btn_filtro_desactivado"
})

btn_filtro_users.addEventListener("click", function(){
    btn_filtro_users.className = "btn_filtro_activado"

    div_tabla_usuarios.style.display = "block"
    div_tabla_documentos.style.display = "none"

    btn_filtro_docs.className = "btn_filtro_desactivado"
})

const btn_subir_doc = document.getElementById("btn_subir_doc")
const div_fondo_subir = document.getElementById("div_fondo_subir")

btn_subir_doc.addEventListener("click", function(){
    div_fondo_subir.style.display = "grid"
})

const btn_cerrar_subir = document.getElementById("btn_cerrar_subir")

btn_cerrar_subir.addEventListener("click", function(){
    div_fondo_subir.style.display = "none"
})

const btn_archivo = document.getElementById("btn_archivo")
const lista_archivos = document.getElementById("lista_archivos")

btn_archivo.addEventListener("click", function(){
    const div_archivo = document.createElement("div")
    const archivo = document.createElement("input")
    const texto_archivo = document.createElement("p")
    const btn_eliminar = document.createElement("button")
    const no_hay_archivos_subir = document.getElementById("no_hay_archivos_subir")

    lista_archivos.append(div_archivo)
    div_archivo.append(archivo)
    div_archivo.append(texto_archivo)

    div_archivo.className = "div_archivo"

    archivo.type = "file"
    archivo.style.display = "none"
    archivo.name = "archivo[]"

    texto_archivo.className = "texto_archivo"

    btn_eliminar.className = "btn_eliminar_archivo"

    archivo.addEventListener("change", function(event){
        const nombre_archivo = event.target.files[0].name;
        texto_archivo.textContent = nombre_archivo
        div_archivo.append(btn_eliminar)
        no_hay_archivos_subir.style.display = "none"
    })

    btn_eliminar.addEventListener("click", function(){
        if(lista_archivos.children.length == 2 ){
            no_hay_archivos_subir.style.display = "block"
        }
        div_archivo.remove()
    })

    archivo.click()
})

const btn_checkbox = document.querySelectorAll('.btn_checkbox')
const box_seleccionar = document.querySelectorAll('.box_seleccionar')
const lista_archivos_descargar = document.getElementById("lista_archivos_descargar")

btn_checkbox.forEach(boton => {
    let estado = false
    boton.addEventListener("click", function(){
        if(estado == false){
            boton.className = "btn_checkbox_checked"

            const box_seleccionar_hidden = boton.previousElementSibling
            box_seleccionar_hidden.click()

            estado = true
        }else {
            boton.className = "btn_checkbox"

            const box_seleccionar_hidden = boton.previousElementSibling
            box_seleccionar_hidden.click()

            estado = false
        }
    })
})

box_seleccionar.forEach(boton => {
    boton.addEventListener("change", function(){
        if(boton.checked){
            const padre = boton.parentElement
            const abuelo = padre.parentElement
            const cerca = abuelo.firstChild
            const titulo = cerca.nextSibling
            const titulo_subida = document.createElement("li")
            const input_titulo = document.createElement("input")

            titulo_subida.className = "titulo_subida_lista"
            titulo_subida.textContent = titulo.textContent

            input_titulo.type = "hidden"
            input_titulo.name = "titulos[]"
            input_titulo.value = titulo.textContent

            lista_archivos_descargar.appendChild(titulo_subida)
            lista_archivos_descargar.appendChild(input_titulo)

            this.titulo_subida_li = titulo_subida
            this.input_titulo_li = input_titulo
        }else{
            this.titulo_subida_li.remove()
            this.titulo_subida_li = null
            this.input_titulo_li.remove()
            this.input_titulo_li = null
        }
    })
})

const btn_mensaje = document.getElementById('btn_mensaje')
const div_fondo_mensaje_enviar = document.getElementById("div_fondo_mensaje_enviar")

btn_mensaje.addEventListener("click", function(){
    div_fondo_mensaje_enviar.style.display = "grid"
})

const btn_cerrar_mensaje = document.getElementById("btn_cerrar_mensaje")

btn_cerrar_mensaje.addEventListener("click", function(){
    div_fondo_mensaje_enviar.style.display = "none"
})

const btn_desplegar_mensajes = document.getElementById('btn_desplegar_mensajes')
const lista_mensajes = document.getElementById('lista_mensajes')

let desplegar = false

btn_desplegar_mensajes.addEventListener("click", function(){
    if(desplegar == false) {
        btn_desplegar_mensajes.style.animationName = "btn_desplegar"
        btn_desplegar_mensajes.style.animationFillMode = "forwards"
        btn_desplegar_mensajes.style.animationDuration = "250ms"
        lista_mensajes.style.display = "grid"
        desplegar = true
    }else {
        btn_desplegar_mensajes.style.animationName = "btn_desplegar_volver"
        btn_desplegar_mensajes.style.animationFillMode = "forwards"
        btn_desplegar_mensajes.style.animationDuration = "250ms"
        lista_mensajes.style.display = "none"
        desplegar = false
    }
})

const div_fondo_mensajes_recibidos = document.querySelectorAll(".div_fondo_mensajes_recibidos")
const btn_mensaje_recibido = document.querySelectorAll(".btn_mensaje_recibido")

div_fondo_mensajes_recibidos.forEach(div_fondo => {
    const div_mensajes_recibidos = div_fondo.querySelector(".div_mensajes_recibidos")
    const btn_cerrar_form = div_mensajes_recibidos.querySelector(".btn_cerrar_form")
    const input_oculto_id_mensaje = div_mensajes_recibidos.querySelector(".input_oculto_id_mensaje")

    btn_cerrar_form.addEventListener("click", function(){
        div_fondo.style.display = "none"
    })

    btn_mensaje_recibido.forEach(boton => {
        const input_id_mensaje_oculto = boton.previousElementSibling
        boton.addEventListener("click", function(){
            if(input_id_mensaje_oculto.value == input_oculto_id_mensaje.value){
                div_fondo.style.display = "grid"
            }
        })
    })
})

const botones_cancelar_eliminar = document.querySelectorAll(".btn_cancelar")

botones_cancelar_eliminar.forEach(boton => {
    const botones_aceptar_cancelar = boton.parentElement
    const div_subida_eliminar = botones_aceptar_cancelar.parentElement
    const div_fondo_subida_eliminar = div_subida_eliminar.parentElement
    
    boton.addEventListener("click", function(){
        div_fondo_subida_eliminar.style.display = "none"
    })
})

const btn_eliminar = document.querySelectorAll(".btn_eliminar")
const div_fondos_subidas_eliminar = document.querySelectorAll(".div_fondo_subida_eliminar")

btn_eliminar.forEach(boton => {
    const input_subida_oculto = boton.nextElementSibling
    boton.addEventListener("click", function(){
        div_fondos_subidas_eliminar.forEach(div => {
            const input_subida_eliminar = div.querySelector(".input_subida_eliminar")
            if(input_subida_eliminar.value == input_subida_oculto.value){
                div.style.display = "grid"
            }
        })
    })  
})

const btn_crear = document.getElementById("btn_crear")
const contenedor_token_crear = document.getElementById("token_crear")
const input_token_crear = contenedor_token_crear.querySelector('input[name="csrfmiddlewaretoken"]')

btn_crear.addEventListener("click", function(){
    const body = document.getElementById("body")
    const div_fondo_crear_documento = document.createElement("div")
    const div_crear_documento = document.createElement("div")
    const btn_cerrar_crear = document.createElement("button")
    const titulo_crear_documento = document.createElement("h2")
    const form_crear_documento = document.createElement("form")

    div_fondo_crear_documento.className = "div_fondo_crear_documento"

    div_crear_documento.className = "div_crear_documento"

    btn_cerrar_crear.className = "btn_cerrar_form"

    titulo_crear_documento.className = "title_form"
    titulo_crear_documento.textContent = "Crear documento"

    form_crear_documento.action = "/crear_documento/"
    form_crear_documento.method = "post"

    body.appendChild(div_fondo_crear_documento)
    div_fondo_crear_documento.appendChild(div_crear_documento)
    div_crear_documento.appendChild(btn_cerrar_crear)
    div_crear_documento.appendChild(titulo_crear_documento)
    div_crear_documento.appendChild(form_crear_documento)

    btn_cerrar_crear.addEventListener("click", function(){
        div_fondo_crear_documento.remove()
    })

    const titulo = document.createElement("input")
    const tipo_subida = document.createElement("input")
    const input_mercado = document.createElement("input")
    const input_instrumento = document.createElement("input")
    const input_descripcion = document.createElement("input")
    const input_fecha_pago = document.createElement("input")
    const input_secuencia_evento = document.createElement("input")
    const input_dividendo = document.createElement("input")
    const input_valor_historico = document.createElement("input")
    const input_factor_actualizacion = document.createElement("input")
    const input_año = document.createElement("input")
    const div_btn_isfut = document.createElement("div")
    const txt_btn_isfut = document.createElement("p")
    const btn_isfut = document.createElement("button")
    const input_oculto_isfut = document.createElement("input")
    const input_factor_8 = document.createElement("input")
    const input_factor_9 = document.createElement("input")
    const input_factor_10 = document.createElement("input")
    const input_factor_11 = document.createElement("input")
    const input_factor_12 = document.createElement("input")
    const input_factor_13 = document.createElement("input")
    const input_factor_14 = document.createElement("input")
    const input_factor_15 = document.createElement("input")
    const input_factor_16 = document.createElement("input")
    const input_factor_17 = document.createElement("input")
    const input_factor_18 = document.createElement("input")
    const input_factor_19 = document.createElement("input")
    const input_factor_20 = document.createElement("input")
    const input_factor_21 = document.createElement("input")
    const input_factor_22 = document.createElement("input")
    const input_factor_23 = document.createElement("input")
    const input_factor_24 = document.createElement("input")
    const input_factor_25 = document.createElement("input")
    const input_factor_26 = document.createElement("input")
    const input_factor_27 = document.createElement("input")
    const input_factor_28 = document.createElement("input")
    const input_factor_29 = document.createElement("input")
    const input_factor_30 = document.createElement("input")
    const input_factor_31 = document.createElement("input")
    const input_factor_32 = document.createElement("input")
    const input_factor_33 = document.createElement("input")
    const input_factor_34 = document.createElement("input")
    const input_factor_35 = document.createElement("input")
    const input_factor_36 = document.createElement("input")
    const input_factor_37 = document.createElement("input")

    const div_botones = document.createElement("div")
    const btn_subir_crear = document.createElement("button")

    titulo.className = "input_form"
    titulo.placeholder = "Título"
    titulo.name = "titulo"

    tipo_subida.className = "input_form"
    tipo_subida.placeholder = "Tipo de subida"
    tipo_subida.name = "tipo_subida"

    input_mercado.className = "input_form"
    input_mercado.placeholder = "Mercado"
    input_mercado.name = "mercado"

    input_instrumento.className = "input_form"
    input_instrumento.placeholder = "Instrumento"
    input_instrumento.name = "instrumento"

    input_descripcion.className = "input_form"    
    input_descripcion.placeholder = "Descripción"
    input_descripcion.name = "descripcion"

    input_fecha_pago.className = "input_form"
    input_fecha_pago.placeholder = "Fecha de pago"
    input_fecha_pago.name = "fecha_pago"
    input_fecha_pago.type = "date"

    input_secuencia_evento.className = "input_form"
    input_secuencia_evento.placeholder = "Secuencia evento"
    input_secuencia_evento.name = "secuencia_evento"
    input_secuencia_evento.type = "number"

    input_dividendo.className = "input_form"
    input_dividendo.placeholder = "Dividendo"
    input_dividendo.name = "dividendo"
    input_dividendo.type = "number"
    input_dividendo.value = 0

    input_valor_historico.className = "input_form"
    input_valor_historico.placeholder = "Valor histórico"
    input_valor_historico.name = "valor_historico"
    input_valor_historico.type = "number"

    input_factor_actualizacion.className = "input_form"
    input_factor_actualizacion.placeholder = "Factor de actualización"
    input_factor_actualizacion.name = "factor_actualizacion"
    input_factor_actualizacion.type = "number"
    input_factor_actualizacion.value = 0

    input_año.className = "input_form"
    input_año.placeholder = "Año"
    input_año.name = "año"

    div_btn_isfut.className = "div_btn_isfut"

    txt_btn_isfut.textContent = "ISFUT"
    txt_btn_isfut.className = "txt_btn_isfut"

    btn_isfut.className = "btn_checkbox"
    btn_isfut.type = "button"

    input_oculto_isfut.name = "isfut"
    input_oculto_isfut.value = "no"

    let btn_estado = false

    btn_isfut.addEventListener("click", function(){
        if(btn_estado == false){
            btn_isfut.className = "btn_checkbox_checked"
            input_oculto_isfut.value = "si"
            btn_estado = true
        }else{
            btn_isfut.className = "btn_checkbox"
            input_oculto_isfut.value = "no"
            btn_estado = false
        }
    })

    input_oculto_isfut.type = "hidden"

    input_factor_8.className = "input_form"
    input_factor_8.placeholder = "Factor 8"
    input_factor_8.name = "factor_8"
    input_factor_8.value = "0.00000000"
    input_factor_8.maxLength = "1"

    input_factor_9.className = "input_form"
    input_factor_9.placeholder = "Factor 9"
    input_factor_9.name = "factor_9"
    input_factor_9.value = "0.00000000"
    input_factor_9.maxLength = "1"

    input_factor_10.className = "input_form"
    input_factor_10.placeholder = "Factor 10"
    input_factor_10.name = "factor_10"
    input_factor_10.value = "0.00000000"
    input_factor_10.maxLength = "1"

    input_factor_11.className = "input_form"
    input_factor_11.placeholder = "Factor 11"
    input_factor_11.name = "factor_11"
    input_factor_11.value = "0.00000000"
    input_factor_11.maxLength = "1"

    input_factor_12.className = "input_form"
    input_factor_12.placeholder = "Factor 12"
    input_factor_12.name = "factor_12"
    input_factor_12.value = "0.00000000"
    input_factor_12.maxLength = "1"

    input_factor_13.className = "input_form"
    input_factor_13.placeholder = "Factor 13"
    input_factor_13.name = "factor_13"
    input_factor_13.value = "0.00000000"
    input_factor_13.maxLength = "1"

    input_factor_14.className = "input_form"
    input_factor_14.placeholder = "Factor 14"
    input_factor_14.name = "factor_14"
    input_factor_14.value = "0.00000000"
    input_factor_14.maxLength = "1"

    input_factor_15.className = "input_form"
    input_factor_15.placeholder = "Factor 15"
    input_factor_15.name = "factor_15"
    input_factor_15.value = "0.00000000"
    input_factor_15.maxLength = "1"

    input_factor_16.className = "input_form"
    input_factor_16.placeholder = "Factor 16"
    input_factor_16.name = "factor_16"
    input_factor_16.value = "0.00000000"
    input_factor_16.maxLength = "1"

    input_factor_17.className = "input_form"
    input_factor_17.placeholder = "Factor 17"
    input_factor_17.name = "factor_17"
    input_factor_17.value = "0.00000000"
    input_factor_17.maxLength = "1"

    input_factor_18.className = "input_form"
    input_factor_18.placeholder = "Factor 18"
    input_factor_18.name = "factor_18"
    input_factor_18.value = "0.00000000"
    input_factor_18.maxLength = "1"

    input_factor_19.className = "input_form"
    input_factor_19.placeholder = "Factor 19"
    input_factor_19.name = "factor_19"
    input_factor_19.value = "0.00000000"
    input_factor_19.maxLength = "1"

    input_factor_20.className = "input_form"
    input_factor_20.placeholder = "Factor 20"
    input_factor_20.name = "factor_20"
    input_factor_20.value = "0.00000000"
    input_factor_20.maxLength = "1"

    input_factor_21.className = "input_form"
    input_factor_21.placeholder = "Factor 21"
    input_factor_21.name = "factor_21"
    input_factor_21.value = "0.00000000"
    input_factor_21.maxLength = "1"

    input_factor_22.className = "input_form"
    input_factor_22.placeholder = "Factor 22"
    input_factor_22.name = "factor_22"
    input_factor_22.value = "0.00000000"
    input_factor_22.maxLength = "1"

    input_factor_23.className = "input_form"
    input_factor_23.placeholder = "Factor 23"
    input_factor_23.name = "factor_23"
    input_factor_23.value = "0.00000000"
    input_factor_23.maxLength = "1"

    input_factor_24.className = "input_form"
    input_factor_24.placeholder = "Factor 24"
    input_factor_24.name = "factor_24"
    input_factor_24.value = "0.00000000"
    input_factor_24.maxLength = "1"

    input_factor_25.className = "input_form"
    input_factor_25.placeholder = "Factor 25"
    input_factor_25.name = "factor_25"
    input_factor_25.value = "0.00000000"
    input_factor_25.maxLength = "1"

    input_factor_26.className = "input_form"
    input_factor_26.placeholder = "Factor 26"
    input_factor_26.name = "factor_26"
    input_factor_26.value = "0.00000000"
    input_factor_26.maxLength = "1"

    input_factor_27.className = "input_form"
    input_factor_27.placeholder = "Factor 27"
    input_factor_27.name = "factor_27"
    input_factor_27.value = "0.00000000"
    input_factor_27.maxLength = "1"

    input_factor_28.className = "input_form"
    input_factor_28.placeholder = "Factor 28"
    input_factor_28.name = "factor_28"
    input_factor_28.value = "0.00000000"
    input_factor_28.maxLength = "1"

    input_factor_29.className = "input_form"
    input_factor_29.placeholder = "Factor 29"
    input_factor_29.name = "factor_29"
    input_factor_29.value = "0.00000000"
    input_factor_29.maxLength = "1"

    input_factor_30.className = "input_form"
    input_factor_30.placeholder = "Factor 30"
    input_factor_30.name = "factor_30"
    input_factor_30.value = "0.00000000"
    input_factor_30.maxLength = "1"

    input_factor_31.className = "input_form"
    input_factor_31.placeholder = "Factor 31"
    input_factor_31.name = "factor_31"
    input_factor_31.value = "0.00000000"
    input_factor_31.maxLength = "1"

    input_factor_32.className = "input_form"
    input_factor_32.placeholder = "Factor 32"
    input_factor_32.name = "factor_32"
    input_factor_32.value = "0.00000000"
    input_factor_32.maxLength = "1"
    
    input_factor_33.className = "input_form"
    input_factor_33.placeholder = "Factor 33"
    input_factor_33.name = "factor_33"
    input_factor_33.value = "0.00000000"
    input_factor_33.maxLength = "1"

    input_factor_34.className = "input_form"
    input_factor_34.placeholder = "Factor 34"
    input_factor_34.name = "factor_34"
    input_factor_34.value = "0.00000000"
    input_factor_34.maxLength = "1"

    input_factor_35.className = "input_form"
    input_factor_35.placeholder = "Factor 35"
    input_factor_35.name = "factor_35"
    input_factor_35.value = "0.00000000"
    input_factor_35.maxLength = "1"

    input_factor_36.className = "input_form"
    input_factor_36.placeholder = "Factor 36"
    input_factor_36.name = "factor_36"
    input_factor_36.value = "0.00000000"
    input_factor_36.maxLength = "1"

    input_factor_37.className = "input_form"
    input_factor_37.placeholder = "Factor 37"
    input_factor_37.name = "factor_37"
    input_factor_37.value = "0.00000000"
    input_factor_37.maxLength = "1"

    div_botones.className = "botones_form"

    btn_subir_crear.className = "btn_enviar"
    btn_subir_crear.type = "submit"
    btn_subir_crear.textContent = "Subir"

    form_crear_documento.appendChild(input_token_crear)
    form_crear_documento.appendChild(titulo)
    form_crear_documento.appendChild(tipo_subida)
    form_crear_documento.appendChild(input_mercado)
    form_crear_documento.appendChild(input_instrumento)
    form_crear_documento.appendChild(input_descripcion)
    form_crear_documento.appendChild(input_fecha_pago)
    form_crear_documento.appendChild(input_secuencia_evento)
    form_crear_documento.appendChild(input_dividendo)
    form_crear_documento.appendChild(input_valor_historico)
    form_crear_documento.appendChild(input_factor_actualizacion)
    form_crear_documento.appendChild(input_año)
    form_crear_documento.appendChild(input_oculto_isfut)
    form_crear_documento.appendChild(div_btn_isfut)
    div_btn_isfut.appendChild(txt_btn_isfut)
    div_btn_isfut.appendChild(btn_isfut)
    
    form_crear_documento.appendChild(input_factor_8)
    form_crear_documento.appendChild(input_factor_9)
    form_crear_documento.appendChild(input_factor_10)
    form_crear_documento.appendChild(input_factor_11)
    form_crear_documento.appendChild(input_factor_12)
    form_crear_documento.appendChild(input_factor_13)
    form_crear_documento.appendChild(input_factor_14)
    form_crear_documento.appendChild(input_factor_15)
    form_crear_documento.appendChild(input_factor_16)
    form_crear_documento.appendChild(input_factor_17)
    form_crear_documento.appendChild(input_factor_18)
    form_crear_documento.appendChild(input_factor_19)
    form_crear_documento.appendChild(input_factor_20)
    form_crear_documento.appendChild(input_factor_21)
    form_crear_documento.appendChild(input_factor_22)
    form_crear_documento.appendChild(input_factor_23)
    form_crear_documento.appendChild(input_factor_24)
    form_crear_documento.appendChild(input_factor_25)
    form_crear_documento.appendChild(input_factor_26)
    form_crear_documento.appendChild(input_factor_27)
    form_crear_documento.appendChild(input_factor_28)
    form_crear_documento.appendChild(input_factor_29)
    form_crear_documento.appendChild(input_factor_30)
    form_crear_documento.appendChild(input_factor_31)
    form_crear_documento.appendChild(input_factor_32)
    form_crear_documento.appendChild(input_factor_33)
    form_crear_documento.appendChild(input_factor_34)
    form_crear_documento.appendChild(input_factor_35)
    form_crear_documento.appendChild(input_factor_36)
    form_crear_documento.appendChild(input_factor_37)

    form_crear_documento.appendChild(div_botones)
    div_botones.appendChild(btn_subir_crear)
})