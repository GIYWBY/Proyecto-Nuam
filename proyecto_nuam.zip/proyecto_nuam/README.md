# Proyecto Nuam

El sistema de Nuam permite la carga masiva de datos, los cuales pueden ser accedidos por los usuarios dentro del sistema.

# Pasos de instalación

Para instalar el proyecto, es necesario descargar las siguientes librerías de python:

- django
- bcrypt
- mysqlclient
- django-localflavor

Es necesario acceder al sitio oficial de MariaDB para instalar "MariaDB Server" https://mariadb.org/download/?t=mariadb&p=mariadb&r=12.0.2&os=windows&cpu=x86_64&pkg=msi&mirror=insacom

Usando un DBMS como "HeidiSQL" (viene junto con la instalación de MariaDB), se debe crear una sesión con los datos predefinidos. Después de acceder
a la sesión, es necesario crear una nueva base de datos llamada "nuam_users".

Luego de crear la base de datos, es necesario realizar las migraciones a la nueva base de datos creada.

Para migrar los modelos necesitamos escribir el siguiente comando dentro de la carpeta raíz del proyecto junto al archivo manage.py:

- py manage.py migrate

Luego de migrar los modelos, ya podemos iniciar el servicio escribiendo el siguiente comando:

- py manage.py runserver

Luego copiamos la ruta que aparece en la consola y la pegamos en el navegador web.